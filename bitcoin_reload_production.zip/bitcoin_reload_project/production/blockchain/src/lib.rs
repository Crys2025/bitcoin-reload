// Bitcoin Reload - Core Library
use std::sync::Arc;
use std::error::Error;
use std::path::Path;
use sha2::Digest; // Adăugat pentru a rezolva eroarea CoreWrapper::new
use tokio::sync::Mutex;
// Înlocuit RwLock cu Mutex pentru a evita probleme de thread safety
// use tokio::sync::RwLock;

// Module imports
pub mod consensus;
pub mod network;
pub mod storage;
pub mod tx_pool;
pub mod rpc;

// Module re-exports
use consensus::{ConsensusEngine, ConsensusConfig};
use network::{NetworkManager, NetworkConfig};
use storage::{StorageManager, StorageConfig};
use tx_pool::{TransactionPool, TxPoolConfig};
use rpc::{RpcConfig}; // Eliminat RpcManager din import pentru a rezolva warning

/// Main blockchain core structure
pub struct BlockchainCore {
    consensus_engine: Arc<ConsensusEngine>,
    network_manager: Arc<NetworkManager>,
    storage_manager: Arc<StorageManager>,
    tx_pool: Arc<TransactionPool>,
    // rpc_manager: Arc<RpcManager>, // Comentat pentru a rezolva warning
}

impl BlockchainCore {
    /// Create a new blockchain core instance
    pub async fn new(
        data_dir: &Path,
        consensus_config: ConsensusConfig,
        network_config: NetworkConfig,
        storage_config: StorageConfig,
        tx_pool_config: TxPoolConfig,
        rpc_config: RpcConfig,
    ) -> Result<Self, Box<dyn Error>> {
        // Initialize storage manager
        let storage_manager = Arc::new(StorageManager::new(data_dir, storage_config)?);
        
        // Initialize transaction pool
        let tx_pool = Arc::new(TransactionPool::new(tx_pool_config));
        
        // Initialize consensus engine
        let consensus_engine = Arc::new(ConsensusEngine::new(
            consensus_config,
            storage_manager.clone(),
            tx_pool.clone(),
        )?);
        
        // Initialize network manager
        let network_manager = Arc::new(NetworkManager::new(
            network_config,
            consensus_engine.clone(),
            tx_pool.clone(),
        )?);
        
        // Initialize RPC manager
        // let rpc_manager = Arc::new(RpcManager::new(
        //     rpc_config,
        //     consensus_engine.clone(),
        //     tx_pool.clone(),
        //     storage_manager.clone(),
        // )?);
        
        Ok(Self {
            consensus_engine,
            network_manager,
            storage_manager,
            tx_pool,
            // rpc_manager,
        })
    }
    
    /// Start the blockchain core
    pub async fn start(&self) -> Result<(), Box<dyn Error>> {
        // Start storage manager
        self.storage_manager.start().await?;
        
        // Start transaction pool
        self.tx_pool.start().await?;
        
        // Start consensus engine
        self.consensus_engine.start().await?;
        
        // Start network manager
        self.network_manager.start().await?;
        
        // Start RPC manager
        // self.rpc_manager.start().await?;
        
        Ok(())
    }
    
    /// Stop the blockchain core
    pub async fn stop(&self) -> Result<(), Box<dyn Error>> {
        // Stop RPC manager
        // self.rpc_manager.stop().await?;
        
        // Stop network manager
        self.network_manager.stop().await?;
        
        // Stop consensus engine
        self.consensus_engine.stop().await?;
        
        // Stop transaction pool
        self.tx_pool.stop().await?;
        
        // Stop storage manager
        self.storage_manager.stop().await?;
        
        Ok(())
    }
    
    /// Get consensus engine reference
    pub fn consensus_engine(&self) -> Arc<ConsensusEngine> {
        self.consensus_engine.clone()
    }
    
    /// Get network manager reference
    pub fn network_manager(&self) -> Arc<NetworkManager> {
        self.network_manager.clone()
    }
    
    /// Get storage manager reference
    pub fn storage_manager(&self) -> Arc<StorageManager> {
        self.storage_manager.clone()
    }
    
    /// Get transaction pool reference
    pub fn tx_pool(&self) -> Arc<TransactionPool> {
        self.tx_pool.clone()
    }
    
    /// Get RPC manager reference
    // pub fn rpc_manager(&self) -> Arc<RpcManager> {
    //     self.rpc_manager.clone()
    // }
    
    /// Calculate hash of data using SHA-256
    pub fn calculate_hash(data: &[u8]) -> Vec<u8> {
        let mut hasher = sha2::Sha256::new(); // Folosim trait-ul Digest
        hasher.update(data);
        hasher.finalize().to_vec()
    }
}
