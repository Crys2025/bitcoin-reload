// Bitcoin Reload - Network Module
use std::collections::{HashMap, HashSet};
use std::error::Error;
use std::sync::Arc;
use std::time::Duration;

use libp2p::{
    core::upgrade,
    gossipsub::{
        Gossipsub, GossipsubConfigBuilder, 
        MessageAuthenticity, ValidationMode, Topic,
    },
    identity::Keypair,
    // Actualizat importurile mdns pentru a folosi noile nume
    mdns::{Behaviour as Mdns, Config as MdnsConfig, Event as MdnsEvent},
    noise,
    swarm::{NetworkBehaviour, SwarmBuilder, SwarmEvent},
    // Actualizat importul tcp pentru a folosi noul nume
    tcp::{GenTcpConfig as TokioTcpConfig},
    Multiaddr, PeerId, Transport,
};

use tokio::sync::{mpsc, Mutex};
use log::{info, error};
use rand::Rng; // Adăugat pentru a rezolva eroarea gen_range

use crate::consensus::{ConsensusEngine, Transaction};
use crate::tx_pool::TransactionPool;

/// Network configuration
pub struct NetworkConfig {
    pub listen_addresses: Vec<Multiaddr>,
    pub bootstrap_nodes: Vec<Multiaddr>,
    pub enable_mdns: bool,
    pub enable_kad: bool,
    pub gossipsub_mesh_n_low: usize,
    pub gossipsub_mesh_n_high: usize,
    pub gossipsub_mesh_outbound_min: usize,
    pub gossipsub_history_length: usize,
    pub gossipsub_history_gossip: usize,
}

impl Default for NetworkConfig {
    fn default() -> Self {
        Self {
            listen_addresses: vec!["/ip4/0.0.0.0/tcp/8333".parse().unwrap()],
            bootstrap_nodes: vec![],
            enable_mdns: true,
            enable_kad: true,
            gossipsub_mesh_n_low: 4,
            gossipsub_mesh_n_high: 12,
            gossipsub_mesh_outbound_min: 2,
            gossipsub_history_length: 5,
            gossipsub_history_gossip: 3,
        }
    }
}

/// Network events
#[derive(Debug)]
pub enum NetworkEvent {
    PeerConnected(PeerId),
    PeerDisconnected(PeerId),
    Gossipsub(libp2p::gossipsub::Event),
    Mdns(MdnsEvent),
}

/// Combined network behaviour
#[derive(NetworkBehaviour)]
pub struct NetworkBehaviour {
    gossipsub: Gossipsub,
    mdns: Mdns,
    #[behaviour(ignore)]
    consensus_engine: Arc<ConsensusEngine>,
    #[behaviour(ignore)]
    tx_pool: Arc<TransactionPool>,
    #[behaviour(ignore)]
    // Actualizat tipul pentru Topic pentru a include parametrul generic
    topics: HashMap<String, Topic<sha2::Sha256>>,
}

impl From<MdnsEvent> for NetworkEvent {
    fn from(event: MdnsEvent) -> Self {
        NetworkEvent::Mdns(event)
    }
}

impl From<libp2p::gossipsub::Event> for NetworkEvent {
    fn from(event: libp2p::gossipsub::Event) -> Self {
        NetworkEvent::Gossipsub(event)
    }
}

/// Network manager
pub struct NetworkManager {
    config: NetworkConfig,
    local_key: Keypair,
    local_peer_id: PeerId,
    swarm: Option<libp2p::swarm::Swarm<NetworkBehaviour>>,
    consensus_engine: Arc<ConsensusEngine>,
    tx_pool: Arc<TransactionPool>,
    // Actualizat tipul pentru Topic pentru a include parametrul generic
    topics: HashMap<String, Topic<sha2::Sha256>>,
    running: Arc<Mutex<bool>>,
    tx_shutdown: Option<mpsc::Sender<()>>,
}

impl NetworkManager {
    /// Create a new network manager
    pub fn new(
        config: NetworkConfig,
        consensus_engine: Arc<ConsensusEngine>,
        tx_pool: Arc<TransactionPool>,
    ) -> Result<Self, Box<dyn Error>> {
        // Generate local key and peer ID
        let local_key = Keypair::generate_ed25519();
        let local_peer_id = PeerId::from(local_key.public());
        
        info!("Local peer ID: {}", local_peer_id);
        
        Ok(Self {
            config,
            local_key,
            local_peer_id,
            swarm: None,
            consensus_engine,
            tx_pool,
            topics: HashMap::new(),
            running: Arc::new(Mutex::new(false)),
            tx_shutdown: None,
        })
    }
    
    /// Initialize the network
    async fn initialize(&mut self) -> Result<(), Box<dyn Error>> {
        // Create transport
        let noise_keys = noise::Keypair::<noise::X25519Spec>::new()
            .into_authentic(&self.local_key)
            .expect("Failed to create noise keys");
        
        let transport = TokioTcpConfig::new()
            .upgrade(upgrade::Version::V1)
            .authenticate(noise::NoiseConfig::xx(noise_keys).into_authenticated())
            .multiplex(libp2p::yamux::YamuxConfig::default())
            .boxed();
        
        // Create gossipsub
        let gossipsub_config = GossipsubConfigBuilder::default()
            .mesh_n_low(self.config.gossipsub_mesh_n_low)
            .mesh_n_high(self.config.gossipsub_mesh_n_high)
            .mesh_outbound_min(self.config.gossipsub_mesh_outbound_min)
            .history_length(self.config.gossipsub_history_length)
            .history_gossip(self.config.gossipsub_history_gossip)
            .validation_mode(ValidationMode::Strict)
            .build()
            .expect("Valid gossipsub config");
        
        let gossipsub = Gossipsub::new(MessageAuthenticity::Signed(self.local_key.clone()), gossipsub_config)
            .expect("Failed to create gossipsub");
        
        // Create MDNS
        let mdns = if self.config.enable_mdns {
            // Actualizat pentru a folosi noile nume
            Mdns::new(MdnsConfig::default())
                .await
                .expect("Failed to create MDNS")
        } else {
            // Actualizat pentru a folosi noile nume
            Mdns::new(MdnsConfig::default())
                .await
                .expect("Failed to create MDNS")
        };
        
        // Create topics
        let tx_topic = Topic::new("transactions");
        let block_topic = Topic::new("blocks");
        
        self.topics.insert("transactions".to_string(), tx_topic.clone());
        self.topics.insert("blocks".to_string(), block_topic.clone());
        
        // Create network behaviour
        let behaviour = NetworkBehaviour {
            gossipsub,
            mdns,
            consensus_engine: self.consensus_engine.clone(),
            tx_pool: self.tx_pool.clone(),
            topics: self.topics.clone(),
        };
        
        // Create swarm
        // Actualizat pentru a folosi noua API SwarmBuilder
        let swarm = SwarmBuilder::with_tokio_executor(transport, behaviour, self.local_peer_id.clone())
            .build();
        
        self.swarm = Some(swarm);
        
        Ok(())
    }
    
    /// Start the network manager
    pub async fn start(&self) -> Result<(), Box<dyn Error>> {
        let mut running = self.running.lock().await;
        if *running {
            return Ok(());
        }
        
        // Clone self for the network task
        let mut network_manager_clone = self.clone();
        
        // Initialize the network
        network_manager_clone.initialize().await?;
        
        // Create shutdown channel
        let (tx_shutdown, mut rx_shutdown) = mpsc::channel::<()>(1);
        
        // Store shutdown sender
        let mut network_manager = self.clone();
        network_manager.tx_shutdown = Some(tx_shutdown);
        
        // Set running flag
        *running = true;
        
        // Spawn network task
        // Modificat pentru a face NetworkManager Send + Sync
        let network_manager_arc = Arc::new(Mutex::new(network_manager_clone));
        
        tokio::spawn(async move {
            let mut network_manager = network_manager_arc.lock().await;
            if let Err(e) = network_manager.run().await {
                error!("Network manager error: {}", e);
            }
        });
        
        Ok(())
    }
    
    /// Run the network manager
    async fn run(&mut self) -> Result<(), Box<dyn Error>> {
        let swarm = self.swarm.as_mut().ok_or("Swarm not initialized")?;
        
        // Listen on all addresses
        for addr in &self.config.listen_addresses {
            swarm.listen_on(addr.clone())?;
        }
        
        // Connect to bootstrap nodes
        for addr in &self.config.bootstrap_nodes {
            swarm.dial(addr.clone())?;
        }
        
        // Subscribe to topics
        if let Some(tx_topic) = self.topics.get("transactions") {
            swarm.behaviour_mut().gossipsub.subscribe(tx_topic)?;
        }
        
        if let Some(block_topic) = self.topics.get("blocks") {
            swarm.behaviour_mut().gossipsub.subscribe(block_topic)?;
        }
        
        // Process events
        loop {
            tokio::select! {
                event = swarm.select_next_some() => {
                    match event {
                        SwarmEvent::Behaviour(NetworkEvent::Mdns(MdnsEvent::Discovered(list))) => {
                            for (peer_id, _) in list {
                                info!("Discovered peer via MDNS: {}", peer_id);
                                swarm.behaviour_mut().gossipsub.add_explicit_peer(&peer_id);
                            }
                        },
                        SwarmEvent::Behaviour(NetworkEvent::Mdns(MdnsEvent::Expired(list))) => {
                            for (peer_id, _) in list {
                                info!("MDNS peer expired: {}", peer_id);
                            }
                        },
                        SwarmEvent::Behaviour(NetworkEvent::Gossipsub(gossipsub_event)) => {
                            match gossipsub_event {
                                libp2p::gossipsub::Event::Message { 
                                    propagation_source: peer_id,
                                    message_id: id,
                                    message,
                                } => {
                                    let topic = message.topic.as_str();
                                    
                                    match topic {
                                        "transactions" => {
                                            info!("Received transaction from {}", peer_id);
                                            
                                            // Deserialize transaction
                                            match bincode::deserialize::<Transaction>(&message.data) {
                                                Ok(tx) => {
                                                    // Add to transaction pool
                                                    self.tx_pool.add_transaction(tx).await;
                                                },
                                                Err(e) => {
                                                    error!("Failed to deserialize transaction: {}", e);
                                                }
                                            }
                                        },
                                        "blocks" => {
                                            info!("Received block from {}", peer_id);
                                            
                                            // Process block in consensus engine
                                            self.consensus_engine.process_remote_block(&message.data).await;
                                        },
                                        _ => {
                                            info!("Received message on unknown topic: {}", topic);
                                        }
                                    }
                                },
                                _ => {}
                            }
                        },
                        SwarmEvent::NewListenAddr { address, .. } => {
                            info!("Listening on {}", address);
                        },
                        SwarmEvent::ConnectionEstablished { peer_id, .. } => {
                            info!("Connected to {}", peer_id);
                        },
                        SwarmEvent::ConnectionClosed { peer_id, .. } => {
                            info!("Disconnected from {}", peer_id);
                        },
                        _ => {}
                    }
                },
                _ = tokio::time::sleep(Duration::from_secs(60)) => {
                    // Periodic tasks
                    self.maintain_peers(swarm).await;
                }
            }
        }
    }
    
    /// Maintain peers
    async fn maintain_peers(&self, swarm: &mut libp2p::swarm::Swarm<NetworkBehaviour>) {
        // Get connected peers
        let connected_peers = swarm.behaviour().mdns.discovered_nodes().count();
        
        info!("Connected to {} peers", connected_peers);
        
        // TODO: Implement more sophisticated peer management
    }
    
    /// Stop the network manager
    pub async fn stop(&self) -> Result<(), Box<dyn Error>> {
        let mut running = self.running.lock().await;
        if !*running {
            return Ok(());
        }
        
        // Send shutdown signal
        if let Some(tx) = &self.tx_shutdown {
            let _ = tx.send(()).await;
        }
        
        // Set running flag
        *running = false;
        
        Ok(())
    }
    
    /// Broadcast transaction
    pub async fn broadcast_transaction(&self, tx: &Transaction) -> Result<(), Box<dyn Error>> {
        if let Some(swarm) = &self.swarm {
            if let Some(topic) = self.topics.get("transactions") {
                // Serialize transaction
                let data = bincode::serialize(tx)?;
                
                // Publish to gossipsub
                swarm.behaviour().gossipsub.publish(topic.clone(), data)?;
            }
        }
        
        Ok(())
    }
    
    /// Broadcast block
    pub async fn broadcast_block(&self, block_data: &[u8]) -> Result<(), Box<dyn Error>> {
        if let Some(swarm) = &self.swarm {
            if let Some(topic) = self.topics.get("blocks") {
                // Publish to gossipsub
                swarm.behaviour().gossipsub.publish(topic.clone(), block_data.to_vec())?;
            }
        }
        
        Ok(())
    }
    
    /// Clone implementation
    fn clone(&self) -> Self {
        Self {
            config: NetworkConfig {
                listen_addresses: self.config.listen_addresses.clone(),
                bootstrap_nodes: self.config.bootstrap_nodes.clone(),
                enable_mdns: self.config.enable_mdns,
                enable_kad: self.config.enable_kad,
                gossipsub_mesh_n_low: self.config.gossipsub_mesh_n_low,
                gossipsub_mesh_n_high: self.config.gossipsub_mesh_n_high,
                gossipsub_mesh_outbound_min: self.config.gossipsub_mesh_outbound_min,
                gossipsub_history_length: self.config.gossipsub_history_length,
                gossipsub_history_gossip: self.config.gossipsub_history_gossip,
            },
            local_key: self.local_key.clone(),
            local_peer_id: self.local_peer_id,
            swarm: None,
            consensus_engine: self.consensus_engine.clone(),
            tx_pool: self.tx_pool.clone(),
            topics: self.topics.clone(),
            running: self.running.clone(),
            tx_shutdown: None,
        }
    }
}
