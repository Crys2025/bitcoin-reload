// Bitcoin Reload - RPC Module
use std::error::Error;
use std::net::SocketAddr;
use std::sync::Arc;

use jsonrpc_http_server::{ServerBuilder, Server};
use jsonrpc_core::{IoHandler, Params, Value, Error as RpcError};
use serde::{Deserialize, Serialize};
use tokio::sync::Mutex;
use log::{info, error}; // Eliminat warn și debug din import pentru a rezolva warning

use crate::consensus::{Transaction, ConsensusEngine}; // Eliminat Block din import pentru a rezolva warning
use crate::storage::StorageManager;
use crate::tx_pool::TransactionPool;

/// RPC configuration
pub struct RpcConfig {
    pub bind_address: SocketAddr,
    pub username: String,
    pub password: String,
}

impl Default for RpcConfig {
    fn default() -> Self {
        Self {
            bind_address: "127.0.0.1:8545".parse().unwrap(),
            username: "user".to_string(),
            password: "password".to_string(),
        }
    }
}

/// RPC manager
pub struct RpcManager {
    config: RpcConfig,
    consensus_engine: Arc<ConsensusEngine>,
    tx_pool: Arc<TransactionPool>,
    storage_manager: Arc<StorageManager>,
    server: Option<Server>,
    running: Arc<Mutex<bool>>,
}

impl RpcManager {
    /// Create a new RPC manager
    pub fn new(
        config: RpcConfig,
        consensus_engine: Arc<ConsensusEngine>,
        tx_pool: Arc<TransactionPool>,
        storage_manager: Arc<StorageManager>,
    ) -> Result<Self, Box<dyn Error>> {
        Ok(Self {
            config,
            consensus_engine,
            tx_pool,
            storage_manager,
            server: None,
            running: Arc::new(Mutex::new(false)),
        })
    }
    
    /// Start the RPC server
    pub async fn start(&mut self) -> Result<(), Box<dyn Error>> {
        let mut running = self.running.lock().await;
        if *running {
            return Ok(());
        }
        
        // Create IoHandler
        let mut io = IoHandler::default();
        
        // Register methods
        self.register_methods(&mut io);
        
        // Start server
        let server = ServerBuilder::new(io)
            .threads(4)
            .start_http(&self.config.bind_address)
            .map_err(|e| format!("Failed to start RPC server: {}", e))?;
        
        self.server = Some(server);
        
        // Set running flag
        *running = true;
        
        info!("RPC server started on {}", self.config.bind_address);
        
        Ok(())
    }
    
    /// Stop the RPC server
    pub async fn stop(&mut self) -> Result<(), Box<dyn Error>> {
        let mut running = self.running.lock().await;
        if !*running {
            return Ok(());
        }
        
        // Stop server
        if let Some(server) = self.server.take() {
            server.close();
        }
        
        // Set running flag
        *running = false;
        
        info!("RPC server stopped");
        
        Ok(())
    }
    
    /// Register RPC methods
    fn register_methods(&self, io: &mut IoHandler) {
        // Clone references for closures
        let consensus_engine = self.consensus_engine.clone();
        let tx_pool = self.tx_pool.clone();
        let storage_manager = self.storage_manager.clone();
        
        // getBlockCount
        io.add_method("getBlockCount", move |_params: Params| {
            let consensus_engine = consensus_engine.clone();
            let storage_manager = storage_manager.clone();
            
            async move {
                match storage_manager.get_latest_block_height().await {
                    Ok(height) => Ok(Value::Number(height.into())),
                    Err(e) => Err(RpcError::internal_error()),
                }
            }
        });
        
        // getBlock
        let consensus_engine2 = self.consensus_engine.clone();
        let storage_manager2 = self.storage_manager.clone();
        io.add_method("getBlock", move |params: Params| {
            let consensus_engine = consensus_engine2.clone();
            let storage_manager = storage_manager2.clone();
            
            async move {
                // Parse parameters
                let hash_or_height = match params.parse::<String>() {
                    Ok(hash) => hash,
                    Err(_) => return Err(RpcError::invalid_params("Invalid parameters")),
                };
                
                // Get block
                let block = if hash_or_height.starts_with("0x") {
                    // Hash
                    let hash = match hex::decode(&hash_or_height[2..]) {
                        Ok(h) => h,
                        Err(_) => return Err(RpcError::invalid_params("Invalid hash")),
                    };
                    
                    match storage_manager.get_block_by_hash(&hash).await {
                        Ok(b) => b,
                        Err(e) => return Err(RpcError::internal_error()),
                    }
                } else {
                    // Height
                    let height = match hash_or_height.parse::<u64>() {
                        Ok(h) => h,
                        Err(_) => return Err(RpcError::invalid_params("Invalid height")),
                    };
                    
                    match storage_manager.get_block_by_height(height).await {
                        Ok(b) => b,
                        Err(e) => return Err(RpcError::internal_error()),
                    }
                };
                
                // Serialize block
                match serde_json::to_value(block) {
                    Ok(v) => Ok(v),
                    Err(_) => Err(RpcError::internal_error()),
                }
            }
        });
        
        // sendTransaction
        let tx_pool2 = self.tx_pool.clone();
        io.add_method("sendTransaction", move |params: Params| {
            let tx_pool = tx_pool2.clone();
            
            async move {
                // Parse parameters
                let tx_hex = match params.parse::<String>() {
                    Ok(tx) => tx,
                    Err(_) => return Err(RpcError::invalid_params("Invalid parameters")),
                };
                
                // Decode transaction
                let tx_data = match hex::decode(&tx_hex) {
                    Ok(d) => d,
                    Err(_) => return Err(RpcError::invalid_params("Invalid transaction hex")),
                };
                
                // Deserialize transaction
                let tx: Transaction = match bincode::deserialize(&tx_data) {
                    Ok(t) => t,
                    Err(_) => return Err(RpcError::invalid_params("Invalid transaction data")),
                };
                
                // Add to transaction pool
                match tx_pool.add_transaction(tx).await {
                    Ok(_) => Ok(Value::String("Transaction accepted".to_string())),
                    Err(e) => Err(RpcError::internal_error()),
                }
            }
        });
        
        // getTransaction
        let storage_manager3 = self.storage_manager.clone();
        io.add_method("getTransaction", move |params: Params| {
            let storage_manager = storage_manager3.clone();
            
            async move {
                // Parse parameters
                let tx_hash_hex = match params.parse::<String>() {
                    Ok(hash) => hash,
                    Err(_) => return Err(RpcError::invalid_params("Invalid parameters")),
                };
                
                // Decode hash
                let tx_hash = match hex::decode(&tx_hash_hex) {
                    Ok(h) => h,
                    Err(_) => return Err(RpcError::invalid_params("Invalid transaction hash")),
                };
                
                // Get transaction
                match storage_manager.get_transaction_by_hash(&tx_hash).await {
                    Ok(tx) => {
                        // Serialize transaction
                        match serde_json::to_value(tx) {
                            Ok(v) => Ok(v),
                            Err(_) => Err(RpcError::internal_error()),
                        }
                    },
                    Err(e) => Err(RpcError::internal_error()),
                }
            }
        });
    }
}
