// Bitcoin Reload - Storage Module
use std::error::Error;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use serde::{Deserialize, Serialize};
use sled::{Db, Tree}; // Importat Tree pentru a rezolva eroarea
use tokio::sync::Mutex;
use log::{info, error}; // Eliminat warn și debug din import pentru a rezolva warning

use crate::consensus::{Block, Transaction};

/// Storage configuration
pub struct StorageConfig {
    pub max_open_files: i32,
    pub cache_capacity: u64,
    pub flush_every_ms: Option<u64>,
}

impl Default for StorageConfig {
    fn default() -> Self {
        Self {
            max_open_files: 1000,
            cache_capacity: 1024 * 1024 * 128, // 128 MB
            flush_every_ms: Some(1000),
        }
    }
}

/// Storage manager
pub struct StorageManager {
    db: Db,
    blocks_tree: Tree,
    transactions_tree: Tree,
    metadata_tree: Tree,
    running: Arc<Mutex<bool>>,
}

impl StorageManager {
    /// Create a new storage manager
    pub fn new(data_dir: &Path, config: StorageConfig) -> Result<Self, Box<dyn Error>> {
        // Create data directory if it doesn't exist
        let db_path = data_dir.join("db");
        std::fs::create_dir_all(&db_path)?;
        
        // Open database
        let db = sled::Config::new()
            .path(&db_path)
            .cache_capacity(config.cache_capacity)
            .flush_every_ms(config.flush_every_ms)
            .open()?;
        
        // Open trees
        let blocks_tree = db.open_tree("blocks")?;
        let transactions_tree = db.open_tree("transactions")?;
        let metadata_tree = db.open_tree("metadata")?;
        
        Ok(Self {
            db,
            blocks_tree,
            transactions_tree,
            metadata_tree,
            running: Arc::new(Mutex::new(false)),
        })
    }
    
    /// Start the storage manager
    pub async fn start(&self) -> Result<(), Box<dyn Error>> {
        let mut running = self.running.lock().await;
        if *running {
            return Ok(());
        }
        
        // Initialize database if needed
        self.initialize_if_needed().await?;
        
        // Set running flag
        *running = true;
        
        Ok(())
    }
    
    /// Stop the storage manager
    pub async fn stop(&self) -> Result<(), Box<dyn Error>> {
        let mut running = self.running.lock().await;
        if !*running {
            return Ok(());
        }
        
        // Flush database
        self.db.flush()?;
        
        // Set running flag
        *running = false;
        
        Ok(())
    }
    
    /// Initialize database if needed
    async fn initialize_if_needed(&self) -> Result<(), Box<dyn Error>> {
        // Check if genesis block exists
        if self.get_block_by_height(0).await.is_err() {
            // Create genesis block
            let genesis_block = self.create_genesis_block();
            
            // Store genesis block
            self.store_block(&genesis_block).await?;
            
            // Set latest block height
            self.set_latest_block_height(0).await?;
            
            info!("Initialized database with genesis block");
        }
        
        Ok(())
    }
    
    /// Create genesis block
    fn create_genesis_block(&self) -> Block {
        // Create coinbase transaction
        let coinbase_tx = Transaction {
            version: 1,
            inputs: vec![],
            outputs: vec![],
            lock_time: 0,
            timestamp: 1717171717, // Fixed timestamp for genesis block
            signature: vec![],
        };
        
        // Create block header
        let header = crate::consensus::BlockHeader {
            version: 1,
            prev_block_hash: vec![0; 32],
            merkle_root: vec![0; 32],
            timestamp: 1717171717, // Fixed timestamp for genesis block
            bits: 0x1d00ffff, // Initial difficulty
            nonce: 0,
            validator: vec![],
            signature: vec![],
        };
        
        // Create block
        Block {
            header,
            transactions: vec![coinbase_tx],
        }
    }
    
    /// Store block
    pub async fn store_block(&self, block: &Block) -> Result<(), Box<dyn Error>> {
        // Serialize block
        let block_data = bincode::serialize(block)?;
        
        // Calculate block hash
        let block_hash = self.calculate_block_hash(block);
        
        // Get block height
        let block_height = match self.get_latest_block_height().await {
            Ok(height) => height + 1,
            Err(_) => 0,
        };
        
        // Store block by hash
        self.blocks_tree.insert(block_hash.clone(), block_data.clone())?;
        
        // Store block by height
        self.blocks_tree.insert(format!("height:{}", block_height).as_bytes(), block_hash.clone())?;
        
        // Store block hash by height
        self.blocks_tree.insert(format!("hash:{}", block_height).as_bytes(), block_hash)?;
        
        // Update latest block height
        self.set_latest_block_height(block_height).await?;
        
        // Store transactions
        for tx in &block.transactions {
            self.store_transaction(tx, &block_hash, block_height).await?;
        }
        
        Ok(())
    }
    
    /// Store transaction
    pub async fn store_transaction(&self, tx: &Transaction, block_hash: &[u8], block_height: u64) -> Result<(), Box<dyn Error>> {
        // Serialize transaction
        let tx_data = bincode::serialize(tx)?;
        
        // Calculate transaction hash
        let tx_hash = self.calculate_transaction_hash(tx);
        
        // Store transaction
        self.transactions_tree.insert(tx_hash.clone(), tx_data)?;
        
        // Store transaction block reference
        self.transactions_tree.insert(format!("block:{}", hex::encode(&tx_hash)).as_bytes(), block_hash)?;
        
        // Store transaction height reference
        self.transactions_tree.insert(format!("height:{}", hex::encode(&tx_hash)).as_bytes(), block_height.to_be_bytes())?;
        
        Ok(())
    }
    
    /// Get block by hash
    pub async fn get_block_by_hash(&self, hash: &[u8]) -> Result<Block, Box<dyn Error>> {
        // Get block data
        let block_data = self.blocks_tree.get(hash)?
            .ok_or("Block not found")?;
        
        // Deserialize block
        let block: Block = bincode::deserialize(&block_data)?;
        
        Ok(block)
    }
    
    /// Get block by height
    pub async fn get_block_by_height(&self, height: u64) -> Result<Block, Box<dyn Error>> {
        // Get block hash
        let block_hash = self.blocks_tree.get(format!("hash:{}", height).as_bytes())?
            .ok_or("Block not found")?;
        
        // Get block
        self.get_block_by_hash(&block_hash).await
    }
    
    /// Get transaction by hash
    pub async fn get_transaction_by_hash(&self, hash: &[u8]) -> Result<Transaction, Box<dyn Error>> {
        // Get transaction data
        let tx_data = self.transactions_tree.get(hash)?
            .ok_or("Transaction not found")?;
        
        // Deserialize transaction
        let tx: Transaction = bincode::deserialize(&tx_data)?;
        
        Ok(tx)
    }
    
    /// Get latest block
    pub async fn get_latest_block(&self) -> Result<Block, Box<dyn Error>> {
        // Get latest block height
        let height = self.get_latest_block_height().await?;
        
        // Get block
        self.get_block_by_height(height).await
    }
    
    /// Get latest block height
    pub async fn get_latest_block_height(&self) -> Result<u64, Box<dyn Error>> {
        // Get latest block height
        let height_data = self.metadata_tree.get("latest_block_height")?
            .ok_or("Latest block height not found")?;
        
        // Convert to u64
        let height = u64::from_be_bytes(height_data.as_ref().try_into()?);
        
        Ok(height)
    }
    
    /// Set latest block height
    async fn set_latest_block_height(&self, height: u64) -> Result<(), Box<dyn Error>> {
        // Convert to bytes
        let height_data = height.to_be_bytes();
        
        // Store latest block height
        self.metadata_tree.insert("latest_block_height", height_data)?;
        
        Ok(())
    }
    
    /// Calculate block hash
    fn calculate_block_hash(&self, block: &Block) -> Vec<u8> {
        // Serialize block header
        let header_data = bincode::serialize(&block.header).unwrap_or_default();
        
        // Calculate hash
        let mut hasher = sha2::Sha256::new();
        hasher.update(&header_data);
        hasher.finalize().to_vec()
    }
    
    /// Calculate transaction hash
    fn calculate_transaction_hash(&self, tx: &Transaction) -> Vec<u8> {
        // Serialize transaction
        let tx_data = bincode::serialize(tx).unwrap_or_default();
        
        // Calculate hash
        let mut hasher = sha2::Sha256::new();
        hasher.update(&tx_data);
        hasher.finalize().to_vec()
    }
    
    /// Compact database
    pub async fn compact_database(&self) -> Result<(), Box<dyn Error>> {
        // Compact trees
        // Înlocuit metoda compact() care nu mai există cu flush()
        self.blocks_tree.flush()?;
        
        // Înlocuit metoda compact() care nu mai există cu flush()
        self.metadata_tree.flush()?;
        
        // Înlocuit metoda compact() care nu mai există cu flush()
        self.transactions_tree.flush()?;
        
        Ok(())
    }
}
