// Bitcoin Reload - Transaction Pool Module
use std::collections::HashMap;
use std::error::Error;
use std::sync::Arc;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use tokio::sync::Mutex;
use log::{info, error, debug}; // Eliminat warn din import pentru a rezolva warning

use crate::consensus::Transaction;

/// Transaction pool configuration
pub struct TxPoolConfig {
    pub max_size: usize,
    pub min_fee_per_byte: u64,
    pub max_age: Duration,
}

impl Default for TxPoolConfig {
    fn default() -> Self {
        Self {
            max_size: 5000,
            min_fee_per_byte: 1,
            max_age: Duration::from_secs(60 * 60 * 24), // 24 hours
        }
    }
}

/// Transaction pool
pub struct TransactionPool {
    config: TxPoolConfig,
    transactions: Arc<Mutex<HashMap<Vec<u8>, (Transaction, u64)>>>, // (tx_hash, (tx, timestamp))
    running: Arc<Mutex<bool>>,
}

impl TransactionPool {
    /// Create a new transaction pool
    pub fn new(config: TxPoolConfig) -> Self {
        Self {
            config,
            transactions: Arc::new(Mutex::new(HashMap::new())),
            running: Arc::new(Mutex::new(false)),
        }
    }
    
    /// Start the transaction pool
    pub async fn start(&self) -> Result<(), Box<dyn Error>> {
        let mut running = self.running.lock().await;
        if *running {
            return Ok(());
        }
        
        // Start cleanup task
        let transactions = self.transactions.clone();
        let max_age = self.config.max_age;
        let running_clone = self.running.clone();
        
        tokio::spawn(async move {
            while *running_clone.lock().await {
                // Sleep for a while
                tokio::time::sleep(Duration::from_secs(60)).await;
                
                // Cleanup old transactions
                let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs();
                let mut txs = transactions.lock().await;
                
                let old_txs: Vec<Vec<u8>> = txs
                    .iter()
                    .filter(|(_, (_, timestamp))| {
                        now - *timestamp > max_age.as_secs()
                    })
                    .map(|(hash, _)| hash.clone())
                    .collect();
                
                for hash in old_txs {
                    txs.remove(&hash);
                }
            }
        });
        
        // Set running flag
        *running = true;
        
        Ok(())
    }
    
    /// Stop the transaction pool
    pub async fn stop(&self) -> Result<(), Box<dyn Error>> {
        let mut running = self.running.lock().await;
        if !*running {
            return Ok(());
        }
        
        // Set running flag
        *running = false;
        
        Ok(())
    }
    
    /// Add transaction to pool
    pub async fn add_transaction(&self, tx: Transaction) -> Result<(), Box<dyn Error>> {
        // Calculate transaction hash
        let tx_hash = self.calculate_transaction_hash(&tx);
        
        // Get current timestamp
        let timestamp = SystemTime::now().duration_since(UNIX_EPOCH)?.as_secs();
        
        // Add transaction to pool
        let mut txs = self.transactions.lock().await;
        
        // Check if pool is full
        if txs.len() >= self.config.max_size {
            return Err("Transaction pool is full".into());
        }
        
        // Check if transaction already exists
        if txs.contains_key(&tx_hash) {
            return Err("Transaction already exists in pool".into());
        }
        
        // Add transaction
        txs.insert(tx_hash, (tx, timestamp));
        
        Ok(())
    }
    
    /// Get transactions from pool
    pub async fn get_transactions(&self, max_count: usize) -> Vec<Transaction> {
        let txs = self.transactions.lock().await;
        
        // Sort transactions by fee
        let mut sorted_txs: Vec<(Vec<u8>, &(Transaction, u64))> = txs
            .iter()
            .collect();
        
        sorted_txs.sort_by(|(_, (tx1, _)), (_, (tx2, _))| {
            let fee1 = self.calculate_transaction_fee(tx1);
            let fee2 = self.calculate_transaction_fee(tx2);
            fee2.cmp(&fee1)
        });
        
        // Get top transactions
        sorted_txs
            .iter()
            .take(max_count)
            .map(|(_, (tx, _))| tx.clone())
            .collect()
    }
    
    /// Remove transactions from pool
    pub async fn remove_transactions(&self, tx_hashes: &[Vec<u8>]) {
        let mut txs = self.transactions.lock().await;
        
        for hash in tx_hashes {
            txs.remove(hash);
        }
    }
    
    /// Calculate transaction hash
    fn calculate_transaction_hash(&self, tx: &Transaction) -> Vec<u8> {
        // Serialize transaction
        let tx_data = bincode::serialize(tx).unwrap_or_default();
        
        // Calculate hash
        let mut hasher = sha2::Sha256::new();
        hasher.update(&tx_data);
        hasher.finalize().to_vec()
    }
    
    /// Calculate transaction fee
    fn calculate_transaction_fee(&self, tx: &Transaction) -> u64 {
        // TODO: Implement proper fee calculation
        // For now, just return a fixed fee
        1000
    }
}
