# Implementare Remedieri Securitate - KMS pentru Gestionarea Cheilor

import os
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

class KeyManagementService:
    """
    Serviciu de gestionare a cheilor pentru Bitcoin Reload
    Implementează un sistem securizat pentru gestionarea cheilor de criptare
    utilizate pentru protejarea cheilor private ale portofelelor
    """
    
    def __init__(self, config_path=None):
        """
        Inițializează serviciul KMS
        
        Args:
            config_path: Calea către fișierul de configurare (opțional)
        """
        self.master_key = None
        self.key_rotation_interval = 30  # zile
        self.keys = {}
        self.active_key_id = None
        
        # Încarcă configurația
        if config_path and os.path.exists(config_path):
            self._load_config(config_path)
        else:
            # Generează o cheie master nouă dacă nu există
            self._initialize_master_key()
            
        # Generează sau încarcă cheile de criptare
        self._initialize_encryption_keys()
    
    def _initialize_master_key(self):
        """
        Inițializează cheia master din variabile de mediu sau generează una nouă
        """
        # Încearcă să încarce cheia master din variabile de mediu
        env_master_key = os.environ.get('BTCR_MASTER_KEY')
        
        if env_master_key:
            try:
                # Decodifică cheia din base64
                self.master_key = base64.urlsafe_b64decode(env_master_key)
                print("Master key loaded from environment variable")
            except Exception as e:
                print(f"Error loading master key from environment: {e}")
                self._generate_master_key()
        else:
            self._generate_master_key()
    
    def _generate_master_key(self):
        """
        Generează o nouă cheie master
        """
        # Generează un salt aleatoriu
        salt = os.urandom(16)
        
        # Generează o parolă aleatorie
        password = os.urandom(32)
        
        # Derivă cheia master folosind PBKDF2
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        
        self.master_key = base64.urlsafe_b64encode(kdf.derive(password))
        
        # Salvează cheia master în variabile de mediu pentru persistență
        os.environ['BTCR_MASTER_KEY'] = self.master_key.decode()
        
        print("New master key generated")
    
    def _initialize_encryption_keys(self):
        """
        Inițializează cheile de criptare
        """
        # Verifică dacă există chei salvate
        keys_file = os.path.join(os.path.dirname(__file__), 'encryption_keys.dat')
        
        if os.path.exists(keys_file):
            # Încarcă cheile existente
            self._load_encryption_keys(keys_file)
        else:
            # Generează o cheie nouă
            self._generate_new_encryption_key()
            
            # Salvează cheile
            self._save_encryption_keys(keys_file)
    
    def _generate_new_encryption_key(self):
        """
        Generează o nouă cheie de criptare
        """
        # Generează un ID unic pentru cheie
        key_id = base64.urlsafe_b64encode(os.urandom(8)).decode()
        
        # Generează o cheie Fernet nouă
        key = Fernet.generate_key()
        
        # Adaugă cheia în dicționar
        self.keys[key_id] = {
            'key': key,
            'created_at': os.path.getmtime(__file__) if os.path.exists(__file__) else 0,
            'rotated': False
        }
        
        # Setează cheia ca activă
        self.active_key_id = key_id
        
        print(f"New encryption key generated with ID: {key_id}")
    
    def _load_encryption_keys(self, keys_file):
        """
        Încarcă cheile de criptare din fișier
        
        Args:
            keys_file: Calea către fișierul cu chei
        """
        try:
            # Creează un obiect Fernet cu cheia master
            fernet = Fernet(self.master_key)
            
            # Citește fișierul criptat
            with open(keys_file, 'rb') as f:
                encrypted_data = f.read()
            
            # Decriptează datele
            decrypted_data = fernet.decrypt(encrypted_data)
            
            # Deserializează dicționarul de chei
            import json
            keys_dict = json.loads(decrypted_data.decode())
            
            # Încarcă cheile și cheia activă
            self.keys = keys_dict['keys']
            self.active_key_id = keys_dict['active_key_id']
            
            print(f"Loaded {len(self.keys)} encryption keys")
            
            # Verifică dacă este necesară rotația cheilor
            self._check_key_rotation()
            
        except Exception as e:
            print(f"Error loading encryption keys: {e}")
            # Generează chei noi în caz de eroare
            self._generate_new_encryption_key()
    
    def _save_encryption_keys(self, keys_file):
        """
        Salvează cheile de criptare în fișier
        
        Args:
            keys_file: Calea către fișierul cu chei
        """
        try:
            # Creează un obiect Fernet cu cheia master
            fernet = Fernet(self.master_key)
            
            # Serializează dicționarul de chei
            import json
            keys_dict = {
                'keys': self.keys,
                'active_key_id': self.active_key_id
            }
            serialized_data = json.dumps(keys_dict).encode()
            
            # Criptează datele
            encrypted_data = fernet.encrypt(serialized_data)
            
            # Salvează în fișier
            os.makedirs(os.path.dirname(keys_file), exist_ok=True)
            with open(keys_file, 'wb') as f:
                f.write(encrypted_data)
            
            print(f"Saved encryption keys to {keys_file}")
            
        except Exception as e:
            print(f"Error saving encryption keys: {e}")
    
    def _check_key_rotation(self):
        """
        Verifică dacă este necesară rotația cheilor
        """
        import time
        current_time = time.time()
        
        # Verifică dacă cheia activă trebuie rotată
        if self.active_key_id in self.keys:
            key_data = self.keys[self.active_key_id]
            key_age_days = (current_time - key_data['created_at']) / (60 * 60 * 24)
            
            if key_age_days > self.key_rotation_interval:
                print(f"Active key is {key_age_days:.1f} days old, rotating...")
                self._rotate_keys()
    
    def _rotate_keys(self):
        """
        Rotește cheile de criptare
        """
        # Marchează cheia curentă ca rotată
        if self.active_key_id in self.keys:
            self.keys[self.active_key_id]['rotated'] = True
        
        # Generează o cheie nouă
        self._generate_new_encryption_key()
        
        # Salvează cheile
        keys_file = os.path.join(os.path.dirname(__file__), 'encryption_keys.dat')
        self._save_encryption_keys(keys_file)
        
        print("Key rotation completed")
    
    def encrypt(self, data):
        """
        Criptează date folosind cheia activă
        
        Args:
            data: Datele de criptat (string sau bytes)
        
        Returns:
            Datele criptate în format base64
        """
        if not isinstance(data, bytes):
            data = str(data).encode()
        
        # Obține cheia activă
        if self.active_key_id not in self.keys:
            raise ValueError("No active encryption key available")
        
        active_key = self.keys[self.active_key_id]['key']
        
        # Creează un obiect Fernet cu cheia activă
        fernet = Fernet(active_key)
        
        # Criptează datele
        encrypted_data = fernet.encrypt(data)
        
        # Adaugă ID-ul cheii la începutul datelor criptate
        result = f"{self.active_key_id}:{encrypted_data.decode()}"
        
        return result
    
    def decrypt(self, encrypted_data):
        """
        Decriptează date
        
        Args:
            encrypted_data: Datele criptate în format "key_id:encrypted_data"
        
        Returns:
            Datele decriptate
        """
        # Separă ID-ul cheii de datele criptate
        parts = encrypted_data.split(':', 1)
        
        if len(parts) != 2:
            raise ValueError("Invalid encrypted data format")
        
        key_id, data = parts
        
        # Verifică dacă cheia există
        if key_id not in self.keys:
            raise ValueError(f"Encryption key with ID {key_id} not found")
        
        # Obține cheia
        key = self.keys[key_id]['key']
        
        # Creează un obiect Fernet cu cheia
        fernet = Fernet(key)
        
        # Decriptează datele
        decrypted_data = fernet.decrypt(data.encode())
        
        return decrypted_data
    
    def get_active_key_id(self):
        """
        Returnează ID-ul cheii active
        
        Returns:
            ID-ul cheii active
        """
        return self.active_key_id

# Exemplu de utilizare
if __name__ == "__main__":
    # Inițializează serviciul KMS
    kms = KeyManagementService()
    
    # Criptează date
    sensitive_data = "private_key_example_12345"
    encrypted = kms.encrypt(sensitive_data)
    print(f"Encrypted: {encrypted}")
    
    # Decriptează date
    decrypted = kms.decrypt(encrypted)
    print(f"Decrypted: {decrypted.decode()}")
