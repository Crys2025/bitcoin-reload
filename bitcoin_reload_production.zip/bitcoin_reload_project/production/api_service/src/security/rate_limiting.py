from flask import request, abort
from functools import wraps
import time
import redis
import os
import logging

# Configurare logging
logger = logging.getLogger(__name__)

# Configurare Redis pentru rate limiting
REDIS_HOST = os.environ.get('REDIS_HOST', 'localhost')
REDIS_PORT = int(os.environ.get('REDIS_PORT', 6379))
REDIS_DB = int(os.environ.get('REDIS_RATE_LIMIT_DB', 0))
REDIS_PASSWORD = os.environ.get('REDIS_PASSWORD', None)

# Încearcă să se conecteze la Redis
try:
    redis_client = redis.Redis(
        host=REDIS_HOST,
        port=REDIS_PORT,
        db=REDIS_DB,
        password=REDIS_PASSWORD,
        decode_responses=True
    )
    redis_client.ping()  # Verifică conexiunea
    logger.info("Connected to Redis for rate limiting")
except redis.ConnectionError as e:
    logger.warning(f"Could not connect to Redis: {e}. Using in-memory rate limiting (not suitable for production).")
    redis_client = None

# Dicționar pentru rate limiting în memorie (fallback)
in_memory_limits = {}

class RateLimiter:
    """
    Implementează rate limiting pentru API
    Limitează numărul de cereri pe IP, endpoint sau utilizator
    """
    
    def __init__(self, limit=100, window=60, by_ip=True, by_endpoint=True, by_user=False):
        """
        Inițializează limitatorul de rată
        
        Args:
            limit: Numărul maxim de cereri permise în fereastra de timp
            window: Fereastra de timp în secunde
            by_ip: Dacă se limitează pe baza IP-ului
            by_endpoint: Dacă se limitează pe baza endpoint-ului
            by_user: Dacă se limitează pe baza ID-ului utilizatorului
        """
        self.limit = limit
        self.window = window
        self.by_ip = by_ip
        self.by_endpoint = by_endpoint
        self.by_user = by_user
    
    def __call__(self, f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Obține identificatorii pentru limitare
            identifiers = self._get_identifiers()
            
            # Verifică limitele pentru fiecare identificator
            for identifier in identifiers:
                if not self._check_limit(identifier):
                    logger.warning(f"Rate limit exceeded for {identifier}")
                    abort(429, description="Too many requests. Please try again later.")
            
            # Execută funcția dacă limitele nu sunt depășite
            return f(*args, **kwargs)
        
        return decorated_function
    
    def _get_identifiers(self):
        """
        Obține identificatorii pentru limitare
        
        Returns:
            Lista de identificatori
        """
        identifiers = []
        
        if self.by_ip:
            # Obține IP-ul clientului
            ip = request.remote_addr
            identifiers.append(f"ip:{ip}")
        
        if self.by_endpoint:
            # Obține endpoint-ul
            endpoint = request.endpoint
            identifiers.append(f"endpoint:{endpoint}")
            
            # Adaugă și combinația IP + endpoint pentru limitare mai precisă
            if self.by_ip:
                ip = request.remote_addr
                identifiers.append(f"ip:{ip}:endpoint:{endpoint}")
        
        if self.by_user and hasattr(request, 'user') and request.user:
            # Obține ID-ul utilizatorului
            user_id = request.user.id
            identifiers.append(f"user:{user_id}")
            
            # Adaugă și combinația utilizator + endpoint
            if self.by_endpoint:
                endpoint = request.endpoint
                identifiers.append(f"user:{user_id}:endpoint:{endpoint}")
        
        return identifiers
    
    def _check_limit(self, identifier):
        """
        Verifică dacă un identificator a depășit limita
        
        Args:
            identifier: Identificatorul de verificat
        
        Returns:
            True dacă limita nu este depășită, False altfel
        """
        current_time = int(time.time())
        key = f"rate_limit:{identifier}:{current_time // self.window}"
        
        if redis_client:
            # Utilizează Redis pentru rate limiting
            count = redis_client.incr(key)
            
            # Setează expirarea cheii dacă este prima incrementare
            if count == 1:
                redis_client.expire(key, self.window)
            
            return count <= self.limit
        else:
            # Fallback la rate limiting în memorie
            if key not in in_memory_limits:
                in_memory_limits[key] = 1
                
                # Curăță cheile expirate
                self._cleanup_memory_limits(current_time)
                
                return True
            else:
                in_memory_limits[key] += 1
                return in_memory_limits[key] <= self.limit
    
    def _cleanup_memory_limits(self, current_time):
        """
        Curăță cheile expirate din dicționarul în memorie
        
        Args:
            current_time: Timpul curent
        """
        # Calculează timestamp-ul minim valid
        min_valid_timestamp = current_time - self.window
        min_valid_window = min_valid_timestamp // self.window
        
        # Șterge cheile expirate
        keys_to_delete = []
        for key in in_memory_limits.keys():
            try:
                # Extrage timestamp-ul din cheie
                key_parts = key.split(':')
                key_timestamp = int(key_parts[-1])
                
                if key_timestamp < min_valid_window:
                    keys_to_delete.append(key)
            except (IndexError, ValueError):
                # Ignoră cheile invalide
                pass
        
        # Șterge cheile expirate
        for key in keys_to_delete:
            del in_memory_limits[key]

# Decorator pentru rate limiting global
def global_rate_limit(limit=100, window=60):
    """
    Decorator pentru rate limiting global
    
    Args:
        limit: Numărul maxim de cereri permise în fereastra de timp
        window: Fereastra de timp în secunde
    """
    return RateLimiter(limit=limit, window=window)

# Decorator pentru rate limiting specific pentru endpoint-uri sensibile
def sensitive_endpoint_rate_limit(limit=10, window=60):
    """
    Decorator pentru rate limiting pentru endpoint-uri sensibile
    
    Args:
        limit: Numărul maxim de cereri permise în fereastra de timp
        window: Fereastra de timp în secunde
    """
    return RateLimiter(limit=limit, window=window, by_ip=True, by_endpoint=True)

# Decorator pentru rate limiting pentru autentificare
def auth_rate_limit(limit=5, window=60):
    """
    Decorator pentru rate limiting pentru autentificare
    
    Args:
        limit: Numărul maxim de cereri permise în fereastra de timp
        window: Fereastra de timp în secunde
    """
    return RateLimiter(limit=limit, window=window, by_ip=True, by_endpoint=False)

# Middleware pentru rate limiting global
def rate_limit_middleware():
    """
    Middleware pentru rate limiting global
    Limitează toate cererile la 1000 pe minut per IP
    """
    limiter = RateLimiter(limit=1000, window=60, by_ip=True, by_endpoint=False)
    
    def middleware():
        identifiers = limiter._get_identifiers()
        
        for identifier in identifiers:
            if not limiter._check_limit(identifier):
                logger.warning(f"Global rate limit exceeded for {identifier}")
                abort(429, description="Too many requests. Please try again later.")
    
    return middleware

# Exemplu de utilizare
"""
# În routes/user.py:

from src.security.rate_limiting import auth_rate_limit, sensitive_endpoint_rate_limit

# Limitează încercările de autentificare la 5 pe minut per IP
@user_bp.route('/login', methods=['POST'])
@auth_rate_limit(limit=5, window=60)
def login():
    # ...

# Limitează cererile de resetare parolă la 3 pe oră per IP
@user_bp.route('/reset-password', methods=['POST'])
@sensitive_endpoint_rate_limit(limit=3, window=3600)
def reset_password():
    # ...
"""
