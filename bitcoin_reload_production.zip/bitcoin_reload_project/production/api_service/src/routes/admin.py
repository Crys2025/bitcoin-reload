from flask import Blueprint, jsonify, request, abort
from src.main import db, blockchain_rpc_call
from src.models.user import User
from src.models.wallet import Wallet
from src.models.transaction import Transaction
from src.routes.user import token_required, admin_required
from datetime import datetime, timedelta
import json

admin_bp = Blueprint('admin', __name__)

# Rută pentru dashboard-ul de administrare
@admin_bp.route('/dashboard', methods=['GET'])
@token_required
@admin_required
def admin_dashboard(current_user):
    # Statistici utilizatori
    total_users = User.query.count()
    active_users = User.query.filter_by(is_active=True).count()
    admin_users = User.query.filter_by(role='admin').count()
    
    # Utilizatori recenți
    recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
    
    # Statistici portofele
    total_wallets = Wallet.query.count()
    active_wallets = Wallet.query.filter_by(is_active=True).count()
    
    # Statistici tranzacții
    total_transactions = Transaction.query.count()
    pending_transactions = Transaction.query.filter_by(status='pending').count()
    confirmed_transactions = Transaction.query.filter_by(status='confirmed').count()
    failed_transactions = Transaction.query.filter_by(status='failed').count()
    
    # Tranzacții recente
    recent_transactions = Transaction.query.order_by(Transaction.created_at.desc()).limit(5).all()
    
    # Statistici blockchain
    blockchain_info = blockchain_rpc_call("getBlockchainInfo")
    blockchain_stats = blockchain_info.get('result', {})
    
    return jsonify({
        'users': {
            'total': total_users,
            'active': active_users,
            'admin': admin_users,
            'recent': [user.to_dict() for user in recent_users]
        },
        'wallets': {
            'total': total_wallets,
            'active': active_wallets
        },
        'transactions': {
            'total': total_transactions,
            'pending': pending_transactions,
            'confirmed': confirmed_transactions,
            'failed': failed_transactions,
            'recent': [tx.to_dict() for tx in recent_transactions]
        },
        'blockchain': blockchain_stats,
        'timestamp': datetime.utcnow().isoformat()
    })

# Rută pentru gestionarea utilizatorilor
@admin_bp.route('/users', methods=['GET'])
@token_required
@admin_required
def admin_users(current_user):
    # Parametri de filtrare
    role = request.args.get('role')
    is_active = request.args.get('is_active')
    search = request.args.get('search')
    
    # Construiește query-ul
    query = User.query
    
    if role:
        query = query.filter_by(role=role)
    
    if is_active is not None:
        is_active_bool = is_active.lower() == 'true'
        query = query.filter_by(is_active=is_active_bool)
    
    if search:
        query = query.filter(
            (User.username.like(f'%{search}%')) |
            (User.email.like(f'%{search}%')) |
            (User.first_name.like(f'%{search}%')) |
            (User.last_name.like(f'%{search}%'))
        )
    
    # Execută query-ul
    users = query.all()
    
    return jsonify({
        'users': [user.to_dict() for user in users],
        'count': len(users)
    })

# Rută pentru gestionarea portofelelor
@admin_bp.route('/wallets', methods=['GET'])
@token_required
@admin_required
def admin_wallets(current_user):
    # Parametri de filtrare
    user_id = request.args.get('user_id')
    is_active = request.args.get('is_active')
    search = request.args.get('search')
    
    # Construiește query-ul
    query = Wallet.query
    
    if user_id:
        user = User.query.filter_by(uuid=user_id).first()
        if user:
            query = query.filter_by(user_id=user.id)
    
    if is_active is not None:
        is_active_bool = is_active.lower() == 'true'
        query = query.filter_by(is_active=is_active_bool)
    
    if search:
        query = query.filter(
            (Wallet.name.like(f'%{search}%')) |
            (Wallet.address.like(f'%{search}%'))
        )
    
    # Execută query-ul
    wallets = query.all()
    
    # Adaugă informații despre utilizator
    wallet_data = []
    for wallet in wallets:
        wallet_dict = wallet.to_dict()
        user = User.query.get(wallet.user_id)
        if user:
            wallet_dict['user'] = {
                'id': user.uuid,
                'username': user.username,
                'email': user.email
            }
        wallet_data.append(wallet_dict)
    
    return jsonify({
        'wallets': wallet_data,
        'count': len(wallets)
    })

# Rută pentru gestionarea tranzacțiilor
@admin_bp.route('/transactions', methods=['GET'])
@token_required
@admin_required
def admin_transactions(current_user):
    # Parametri de filtrare
    status = request.args.get('status')
    wallet_id = request.args.get('wallet_id')
    user_id = request.args.get('user_id')
    search = request.args.get('search')
    
    # Construiește query-ul
    query = Transaction.query
    
    if status:
        query = query.filter_by(status=status)
    
    if wallet_id:
        wallet = Wallet.query.filter_by(uuid=wallet_id).first()
        if wallet:
            query = query.filter(
                (Transaction.sender_wallet_id == wallet.id) |
                (Transaction.recipient_wallet_id == wallet.id)
            )
    
    if user_id:
        user = User.query.filter_by(uuid=user_id).first()
        if user:
            user_wallets = Wallet.query.filter_by(user_id=user.id).all()
            wallet_ids = [w.id for w in user_wallets]
            if wallet_ids:
                query = query.filter(
                    (Transaction.sender_wallet_id.in_(wallet_ids)) |
                    (Transaction.recipient_wallet_id.in_(wallet_ids))
                )
    
    if search:
        query = query.filter(
            Transaction.tx_hash.like(f'%{search}%')
        )
    
    # Execută query-ul
    transactions = query.order_by(Transaction.created_at.desc()).all()
    
    return jsonify({
        'transactions': [tx.to_dict() for tx in transactions],
        'count': len(transactions)
    })

# Rută pentru statistici și rapoarte
@admin_bp.route('/stats', methods=['GET'])
@token_required
@admin_required
def admin_stats(current_user):
    # Parametri pentru interval de timp
    days = request.args.get('days', default=30, type=int)
    start_date = datetime.utcnow() - timedelta(days=days)
    
    # Statistici utilizatori în timp
    user_stats = db.session.query(
        db.func.date(User.created_at).label('date'),
        db.func.count(User.id).label('count')
    ).filter(User.created_at >= start_date).group_by(db.func.date(User.created_at)).all()
    
    user_data = [{'date': str(stat.date), 'count': stat.count} for stat in user_stats]
    
    # Statistici tranzacții în timp
    tx_stats = db.session.query(
        db.func.date(Transaction.created_at).label('date'),
        db.func.count(Transaction.id).label('count'),
        db.func.sum(Transaction.amount).label('volume')
    ).filter(Transaction.created_at >= start_date).group_by(db.func.date(Transaction.created_at)).all()
    
    tx_data = [{'date': str(stat.date), 'count': stat.count, 'volume': stat.volume or 0} for stat in tx_stats]
    
    # Statistici portofele în timp
    wallet_stats = db.session.query(
        db.func.date(Wallet.created_at).label('date'),
        db.func.count(Wallet.id).label('count')
    ).filter(Wallet.created_at >= start_date).group_by(db.func.date(Wallet.created_at)).all()
    
    wallet_data = [{'date': str(stat.date), 'count': stat.count} for stat in wallet_stats]
    
    return jsonify({
        'users': user_data,
        'transactions': tx_data,
        'wallets': wallet_data,
        'period': {
            'days': days,
            'start_date': start_date.isoformat(),
            'end_date': datetime.utcnow().isoformat()
        }
    })

# Rută pentru acțiuni de administrare blockchain
@admin_bp.route('/blockchain/actions', methods=['POST'])
@token_required
@admin_required
def admin_blockchain_actions(current_user):
    data = request.get_json()
    
    if not data or 'action' not in data:
        return jsonify({'error': 'Acțiune nespecificată!'}), 400
    
    action = data['action']
    
    if action == 'restart_node':
        # Acțiune de restart nod blockchain
        response = blockchain_rpc_call("restartNode")
        return jsonify({
            'message': 'Comandă de restart trimisă către nodul blockchain',
            'result': response.get('result', {})
        })
    
    elif action == 'export_blockchain':
        # Acțiune de export blockchain
        file_path = data.get('file_path', '/tmp/blockchain_export.dat')
        response = blockchain_rpc_call("exportBlockchain", [file_path])
        return jsonify({
            'message': f'Export blockchain în {file_path}',
            'result': response.get('result', {})
        })
    
    elif action == 'compact_database':
        # Acțiune de compactare bază de date blockchain
        response = blockchain_rpc_call("compactDatabase")
        return jsonify({
            'message': 'Comandă de compactare trimisă către nodul blockchain',
            'result': response.get('result', {})
        })
    
    else:
        return jsonify({'error': 'Acțiune necunoscută!'}), 400

# Rută pentru configurare sistem
@admin_bp.route('/settings', methods=['GET', 'PUT'])
@token_required
@admin_required
def admin_settings(current_user):
    settings_file = 'admin_settings.json'
    
    if request.method == 'GET':
        # Citește setările
        try:
            with open(settings_file, 'r') as f:
                settings = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            # Setări implicite
            settings = {
                'maintenance_mode': False,
                'registration_enabled': True,
                'min_transaction_fee': 1,
                'max_wallets_per_user': 5,
                'blockchain_sync_interval': 60,
                'notification_email': 'admin@bitcoinreload.com'
            }
            
            # Salvează setările implicite
            with open(settings_file, 'w') as f:
                json.dump(settings, f)
        
        return jsonify(settings)
    
    elif request.method == 'PUT':
        data = request.get_json()
        
        # Validare date
        if not data:
            return jsonify({'error': 'Date lipsă!'}), 400
        
        # Citește setările existente
        try:
            with open(settings_file, 'r') as f:
                settings = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            settings = {}
        
        # Actualizează setările
        for key, value in data.items():
            settings[key] = value
        
        # Salvează setările
        with open(settings_file, 'w') as f:
            json.dump(settings, f)
        
        return jsonify({
            'message': 'Setări actualizate cu succes!',
            'settings': settings
        })
