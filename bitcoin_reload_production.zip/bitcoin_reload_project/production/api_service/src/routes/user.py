from flask import Blueprint, jsonify, request, abort
from src.main import db, blockchain_rpc_call
from src.models.user import User
from datetime import datetime
import jwt
import os
from functools import wraps

user_bp = Blueprint('user', __name__)

# Configurare JWT
JWT_SECRET = os.getenv('JWT_SECRET', 'bitcoin-reload-secret-key')
JWT_ALGORITHM = 'HS256'
JWT_EXPIRATION = 86400  # 24 ore în secunde

# Decorator pentru autentificare
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        # Verifică dacă token-ul este în header
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            if auth_header.startswith('Bearer '):
                token = auth_header.split(' ')[1]
        
        if not token:
            return jsonify({'error': 'Token lipsă!'}), 401
        
        try:
            # Decodifică token-ul
            data = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
            current_user = User.query.filter_by(uuid=data['user_id']).first()
            
            if not current_user:
                return jsonify({'error': 'Token invalid!'}), 401
            
            if not current_user.is_active:
                return jsonify({'error': 'Cont dezactivat!'}), 403
                
        except jwt.ExpiredSignatureError:
            return jsonify({'error': 'Token expirat!'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Token invalid!'}), 401
            
        return f(current_user, *args, **kwargs)
    
    return decorated

# Decorator pentru verificarea rolului de admin
def admin_required(f):
    @wraps(f)
    def decorated(current_user, *args, **kwargs):
        if current_user.role != 'admin':
            return jsonify({'error': 'Acces interzis!'}), 403
        return f(current_user, *args, **kwargs)
    
    return decorated

# Rută pentru înregistrare utilizator
@user_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    
    # Validare date
    required_fields = ['username', 'email', 'password', 'first_name', 'last_name']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'Câmpul {field} este obligatoriu!'}), 400
    
    # Verifică dacă username sau email există deja
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'error': 'Numele de utilizator există deja!'}), 400
        
    if User.query.filter_by(email=data['email']).first():
        return jsonify({'error': 'Adresa de email există deja!'}), 400
    
    # Creează utilizatorul
    user = User(
        username=data['username'],
        email=data['email'],
        password=data['password'],
        first_name=data['first_name'],
        last_name=data['last_name']
    )
    
    db.session.add(user)
    db.session.commit()
    
    return jsonify({
        'message': 'Utilizator înregistrat cu succes!',
        'user': user.to_dict()
    }), 201

# Rută pentru autentificare
@user_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    
    # Validare date
    if not data or not data.get('username') or not data.get('password'):
        return jsonify({'error': 'Date de autentificare incomplete!'}), 400
    
    # Caută utilizatorul
    user = User.query.filter_by(username=data['username']).first()
    
    if not user or not user.check_password(data['password']):
        return jsonify({'error': 'Nume de utilizator sau parolă incorecte!'}), 401
    
    if not user.is_active:
        return jsonify({'error': 'Cont dezactivat!'}), 403
    
    # Actualizează data ultimei autentificări
    user.last_login = datetime.utcnow()
    db.session.commit()
    
    # Generează token JWT
    token_payload = {
        'user_id': user.uuid,
        'username': user.username,
        'role': user.role,
        'exp': datetime.utcnow().timestamp() + JWT_EXPIRATION
    }
    
    token = jwt.encode(token_payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    
    return jsonify({
        'message': 'Autentificare reușită!',
        'token': token,
        'user': user.to_dict(),
        'expires_in': JWT_EXPIRATION
    })

# Rută pentru profilul utilizatorului
@user_bp.route('/profile', methods=['GET'])
@token_required
def get_profile(current_user):
    return jsonify({
        'user': current_user.to_dict()
    })

# Rută pentru actualizarea profilului
@user_bp.route('/profile', methods=['PUT'])
@token_required
def update_profile(current_user):
    data = request.get_json()
    
    # Câmpuri care pot fi actualizate
    allowed_fields = ['first_name', 'last_name', 'email']
    
    for field in allowed_fields:
        if field in data:
            setattr(current_user, field, data[field])
    
    # Actualizare parolă (opțional)
    if 'password' in data and data['password']:
        current_user.set_password(data['password'])
    
    db.session.commit()
    
    return jsonify({
        'message': 'Profil actualizat cu succes!',
        'user': current_user.to_dict()
    })

# Rută pentru listarea tuturor utilizatorilor (doar admin)
@user_bp.route('/', methods=['GET'])
@token_required
@admin_required
def get_all_users(current_user):
    users = User.query.all()
    return jsonify({
        'users': [user.to_dict() for user in users]
    })

# Rută pentru obținerea unui utilizator specific (doar admin)
@user_bp.route('/<user_id>', methods=['GET'])
@token_required
@admin_required
def get_user(current_user, user_id):
    user = User.query.filter_by(uuid=user_id).first()
    
    if not user:
        return jsonify({'error': 'Utilizator negăsit!'}), 404
    
    return jsonify({
        'user': user.to_dict()
    })

# Rută pentru actualizarea unui utilizator (doar admin)
@user_bp.route('/<user_id>', methods=['PUT'])
@token_required
@admin_required
def update_user(current_user, user_id):
    user = User.query.filter_by(uuid=user_id).first()
    
    if not user:
        return jsonify({'error': 'Utilizator negăsit!'}), 404
    
    data = request.get_json()
    
    # Câmpuri care pot fi actualizate
    allowed_fields = ['first_name', 'last_name', 'email', 'is_active', 'role']
    
    for field in allowed_fields:
        if field in data:
            setattr(user, field, data[field])
    
    # Actualizare parolă (opțional)
    if 'password' in data and data['password']:
        user.set_password(data['password'])
    
    db.session.commit()
    
    return jsonify({
        'message': 'Utilizator actualizat cu succes!',
        'user': user.to_dict()
    })

# Rută pentru ștergerea unui utilizator (doar admin)
@user_bp.route('/<user_id>', methods=['DELETE'])
@token_required
@admin_required
def delete_user(current_user, user_id):
    user = User.query.filter_by(uuid=user_id).first()
    
    if not user:
        return jsonify({'error': 'Utilizator negăsit!'}), 404
    
    # Nu permitem ștergerea propriului cont
    if user.id == current_user.id:
        return jsonify({'error': 'Nu puteți șterge propriul cont!'}), 400
    
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({
        'message': 'Utilizator șters cu succes!'
    })
