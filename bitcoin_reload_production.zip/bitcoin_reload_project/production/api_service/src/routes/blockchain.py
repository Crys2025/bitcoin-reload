from flask import Blueprint, jsonify, request, abort
from src.main import db, blockchain_rpc_call
from src.models.transaction import Transaction
from src.models.wallet import Wallet
from src.routes.user import token_required, admin_required
from datetime import datetime

blockchain_bp = Blueprint('blockchain', __name__)

# Rută pentru obținerea informațiilor despre blockchain
@blockchain_bp.route('/info', methods=['GET'])
@token_required
def get_blockchain_info(current_user):
    response = blockchain_rpc_call("getBlockchainInfo")
    
    if 'error' in response:
        return jsonify({'error': 'Eroare la obținerea informațiilor blockchain!'}), 500
    
    return jsonify(response.get('result', {}))

# Rută pentru obținerea unui bloc după hash
@blockchain_bp.route('/blocks/<block_hash>', methods=['GET'])
@token_required
def get_block_by_hash(current_user, block_hash):
    response = blockchain_rpc_call("getBlockByHash", [block_hash])
    
    if 'error' in response:
        return jsonify({'error': 'Bloc negăsit!'}), 404
    
    return jsonify(response.get('result', {}))

# Rută pentru obținerea unui bloc după înălțime
@blockchain_bp.route('/blocks/height/<int:height>', methods=['GET'])
@token_required
def get_block_by_height(current_user, height):
    response = blockchain_rpc_call("getBlockByHeight", [height])
    
    if 'error' in response:
        return jsonify({'error': 'Bloc negăsit!'}), 404
    
    return jsonify(response.get('result', {}))

# Rută pentru obținerea blocului cel mai recent
@blockchain_bp.route('/blocks/latest', methods=['GET'])
@token_required
def get_latest_block(current_user):
    response = blockchain_rpc_call("getLatestBlock")
    
    if 'error' in response:
        return jsonify({'error': 'Eroare la obținerea blocului recent!'}), 500
    
    return jsonify(response.get('result', {}))

# Rută pentru obținerea unei tranzacții după hash
@blockchain_bp.route('/transactions/<tx_hash>', methods=['GET'])
@token_required
def get_transaction_by_hash(current_user, tx_hash):
    # Verifică mai întâi în baza de date locală
    transaction = Transaction.query.filter_by(tx_hash=tx_hash).first()
    
    if transaction:
        # Actualizează statusul tranzacției dacă este necesar
        if transaction.status == 'pending':
            tx_response = blockchain_rpc_call("getTransactionByHash", [tx_hash])
            
            if 'result' in tx_response:
                tx_data = tx_response.get('result', {})
                
                if 'blockHeight' in tx_data and tx_data['blockHeight']:
                    transaction.status = 'confirmed'
                    transaction.block_height = tx_data['blockHeight']
                    transaction.block_hash = tx_data.get('blockHash', '')
                    transaction.confirmation_time = datetime.utcnow()
                    db.session.commit()
        
        return jsonify({
            'transaction': transaction.to_dict()
        })
    
    # Dacă nu există în baza de date, caută în blockchain
    response = blockchain_rpc_call("getTransactionByHash", [tx_hash])
    
    if 'error' in response:
        return jsonify({'error': 'Tranzacție negăsită!'}), 404
    
    return jsonify(response.get('result', {}))

# Rută pentru obținerea informațiilor despre pool-ul de tranzacții
@blockchain_bp.route('/mempool', methods=['GET'])
@token_required
def get_mempool_info(current_user):
    response = blockchain_rpc_call("getTransactionPoolInfo")
    
    if 'error' in response:
        return jsonify({'error': 'Eroare la obținerea informațiilor mempool!'}), 500
    
    return jsonify(response.get('result', {}))

# Rută pentru verificarea stării rețelei
@blockchain_bp.route('/network', methods=['GET'])
@token_required
def get_network_info(current_user):
    response = blockchain_rpc_call("getNetworkInfo")
    
    if 'error' in response:
        return jsonify({'error': 'Eroare la obținerea informațiilor rețea!'}), 500
    
    return jsonify(response.get('result', {}))

# Rută pentru obținerea statisticilor blockchain
@blockchain_bp.route('/stats', methods=['GET'])
@token_required
def get_blockchain_stats(current_user):
    # Obține informații blockchain
    blockchain_info = blockchain_rpc_call("getBlockchainInfo")
    
    if 'error' in blockchain_info:
        return jsonify({'error': 'Eroare la obținerea statisticilor blockchain!'}), 500
    
    # Obține informații mempool
    mempool_info = blockchain_rpc_call("getTransactionPoolInfo")
    
    # Obține informații rețea
    network_info = blockchain_rpc_call("getNetworkInfo")
    
    # Calculează statistici
    stats = {
        'blockchain': blockchain_info.get('result', {}),
        'mempool': mempool_info.get('result', {}),
        'network': network_info.get('result', {}),
        'timestamp': datetime.utcnow().isoformat()
    }
    
    return jsonify(stats)
