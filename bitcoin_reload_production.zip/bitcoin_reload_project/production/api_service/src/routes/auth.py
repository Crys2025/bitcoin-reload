from flask import Blueprint, request, jsonify, abort
import jwt
import datetime
import os
from functools import wraps
from src.models.user import User
from src.security.rate_limiting import auth_rate_limit, sensitive_endpoint_rate_limit
from src.security.key_management import KeyManagementService

# Inițializare KMS pentru gestionarea tokenurilor JWT
kms = KeyManagementService()

# Configurare JWT
JWT_SECRET = os.getenv('JWT_SECRET', 'bitcoin-reload-secret-key')
JWT_ALGORITHM = 'HS256'
JWT_EXPIRATION_NORMAL = 3600  # 1 oră în secunde pentru operațiuni normale
JWT_EXPIRATION_EXTENDED = 86400  # 24 ore în secunde pentru "remember me"

# Inițializare Redis pentru token blacklist
try:
    import redis
    REDIS_HOST = os.environ.get('REDIS_HOST', 'localhost')
    REDIS_PORT = int(os.environ.get('REDIS_PORT', 6379))
    REDIS_DB = int(os.environ.get('REDIS_TOKEN_DB', 1))
    REDIS_PASSWORD = os.environ.get('REDIS_PASSWORD', None)
    
    redis_client = redis.Redis(
        host=REDIS_HOST,
        port=REDIS_PORT,
        db=REDIS_DB,
        password=REDIS_PASSWORD,
        decode_responses=True
    )
    redis_client.ping()  # Verifică conexiunea
    print("Connected to Redis for token blacklist")
except Exception as e:
    print(f"Could not connect to Redis: {e}. Token revocation will not work properly.")
    redis_client = None

# Blueprint pentru autentificare
auth_bp = Blueprint('auth', __name__)

# Decorator pentru autentificare
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        # Verifică dacă token-ul este în header
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            if auth_header.startswith('Bearer '):
                token = auth_header.split(' ')[1]
        
        if not token:
            return jsonify({'error': 'Token lipsă!'}), 401
        
        try:
            # Verifică dacă token-ul este revocat
            if redis_client and redis_client.exists(f"revoked_token:{token}"):
                return jsonify({'error': 'Token revocat!'}), 401
            
            # Decodifică token-ul
            data = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
            current_user = User.query.filter_by(uuid=data['user_id']).first()
            
            if not current_user:
                return jsonify({'error': 'Token invalid!'}), 401
            
            if not current_user.is_active:
                return jsonify({'error': 'Cont dezactivat!'}), 403
            
            # Adaugă utilizatorul la request pentru a fi disponibil în view-uri
            request.user = current_user
                
        except jwt.ExpiredSignatureError:
            return jsonify({'error': 'Token expirat!'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Token invalid!'}), 401
            
        return f(*args, **kwargs)
    
    return decorated

# Decorator pentru verificarea rolului de admin
def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not hasattr(request, 'user') or not request.user:
            return jsonify({'error': 'Autentificare necesară!'}), 401
            
        if request.user.role != 'admin':
            return jsonify({'error': 'Acces interzis!'}), 403
        return f(*args, **kwargs)
    
    return decorated

# Rută pentru înregistrare utilizator
@auth_bp.route('/register', methods=['POST'])
@auth_rate_limit(limit=3, window=300)  # Limitează la 3 înregistrări la 5 minute per IP
def register():
    data = request.get_json()
    
    # Validare date
    required_fields = ['username', 'email', 'password', 'first_name', 'last_name']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'Câmpul {field} este obligatoriu!'}), 400
    
    # Verifică dacă username sau email există deja
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'error': 'Numele de utilizator există deja!'}), 400
        
    if User.query.filter_by(email=data['email']).first():
        return jsonify({'error': 'Adresa de email există deja!'}), 400
    
    # Creează utilizatorul
    user = User(
        username=data['username'],
        email=data['email'],
        password=data['password'],
        first_name=data['first_name'],
        last_name=data['last_name']
    )
    
    from src.main import db
    db.session.add(user)
    db.session.commit()
    
    return jsonify({
        'message': 'Utilizator înregistrat cu succes!',
        'user': user.to_dict()
    }), 201

# Rută pentru autentificare
@auth_bp.route('/login', methods=['POST'])
@auth_rate_limit(limit=5, window=60)  # Limitează la 5 încercări pe minut per IP
def login():
    data = request.get_json()
    
    # Validare date
    if not data or not data.get('username') or not data.get('password'):
        return jsonify({'error': 'Date de autentificare incomplete!'}), 400
    
    # Caută utilizatorul
    user = User.query.filter_by(username=data['username']).first()
    
    if not user or not user.check_password(data['password']):
        return jsonify({'error': 'Nume de utilizator sau parolă incorecte!'}), 401
    
    if not user.is_active:
        return jsonify({'error': 'Cont dezactivat!'}), 403
    
    # Actualizează data ultimei autentificări
    user.last_login = datetime.datetime.utcnow()
    
    from src.main import db
    db.session.commit()
    
    # Determină durata token-ului
    remember_me = data.get('remember_me', False)
    expiration = JWT_EXPIRATION_EXTENDED if remember_me else JWT_EXPIRATION_NORMAL
    expiration_timestamp = datetime.datetime.utcnow() + datetime.timedelta(seconds=expiration)
    
    # Generează token JWT
    token_payload = {
        'user_id': user.uuid,
        'username': user.username,
        'role': user.role,
        'exp': expiration_timestamp
    }
    
    token = jwt.encode(token_payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    
    return jsonify({
        'message': 'Autentificare reușită!',
        'token': token,
        'user': user.to_dict(),
        'expires_in': expiration,
        'expires_at': expiration_timestamp.isoformat()
    })

# Rută pentru logout (revocarea token-ului)
@auth_bp.route('/logout', methods=['POST'])
@token_required
def logout():
    token = None
    
    # Obține token-ul din header
    if 'Authorization' in request.headers:
        auth_header = request.headers['Authorization']
        if auth_header.startswith('Bearer '):
            token = auth_header.split(' ')[1]
    
    if not token:
        return jsonify({'error': 'Token lipsă!'}), 400
    
    # Decodifică token-ul pentru a obține timpul de expirare
    try:
        data = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        exp_timestamp = data.get('exp', 0)
        
        # Calculează timpul rămas până la expirare
        current_timestamp = datetime.datetime.utcnow().timestamp()
        ttl = max(0, int(exp_timestamp - current_timestamp))
        
        # Adaugă token-ul în blacklist
        if redis_client:
            redis_client.setex(f"revoked_token:{token}", ttl, 1)
            
        return jsonify({'message': 'Logout reușit!'})
    except Exception as e:
        return jsonify({'error': f'Eroare la procesarea token-ului: {str(e)}'}), 400

# Rută pentru reîmprospătarea token-ului
@auth_bp.route('/refresh-token', methods=['POST'])
@token_required
def refresh_token():
    # Obține utilizatorul curent din request (adăugat de decorator)
    current_user = request.user
    
    # Determină durata token-ului
    data = request.get_json() or {}
    remember_me = data.get('remember_me', False)
    expiration = JWT_EXPIRATION_EXTENDED if remember_me else JWT_EXPIRATION_NORMAL
    expiration_timestamp = datetime.datetime.utcnow() + datetime.timedelta(seconds=expiration)
    
    # Generează token JWT nou
    token_payload = {
        'user_id': current_user.uuid,
        'username': current_user.username,
        'role': current_user.role,
        'exp': expiration_timestamp
    }
    
    token = jwt.encode(token_payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    
    # Revocă token-ul vechi
    old_token = None
    if 'Authorization' in request.headers:
        auth_header = request.headers['Authorization']
        if auth_header.startswith('Bearer '):
            old_token = auth_header.split(' ')[1]
    
    if old_token and redis_client:
        try:
            data = jwt.decode(old_token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
            exp_timestamp = data.get('exp', 0)
            
            # Calculează timpul rămas până la expirare
            current_timestamp = datetime.datetime.utcnow().timestamp()
            ttl = max(0, int(exp_timestamp - current_timestamp))
            
            # Adaugă token-ul vechi în blacklist
            redis_client.setex(f"revoked_token:{old_token}", ttl, 1)
        except:
            pass
    
    return jsonify({
        'message': 'Token reîmprospătat cu succes!',
        'token': token,
        'user': current_user.to_dict(),
        'expires_in': expiration,
        'expires_at': expiration_timestamp.isoformat()
    })

# Rută pentru verificarea token-ului
@auth_bp.route('/verify-token', methods=['GET'])
@token_required
def verify_token():
    # Obține utilizatorul curent din request (adăugat de decorator)
    current_user = request.user
    
    return jsonify({
        'message': 'Token valid!',
        'user': current_user.to_dict()
    })

# Rută pentru schimbarea parolei
@auth_bp.route('/change-password', methods=['POST'])
@token_required
@sensitive_endpoint_rate_limit(limit=3, window=300)  # Limitează la 3 încercări la 5 minute
def change_password():
    data = request.get_json()
    
    # Validare date
    if not data or not data.get('current_password') or not data.get('new_password'):
        return jsonify({'error': 'Date incomplete!'}), 400
    
    # Obține utilizatorul curent
    current_user = request.user
    
    # Verifică parola curentă
    if not current_user.check_password(data['current_password']):
        return jsonify({'error': 'Parola curentă este incorectă!'}), 401
    
    # Schimbă parola
    current_user.set_password(data['new_password'])
    
    from src.main import db
    db.session.commit()
    
    # Revocă toate token-urile existente pentru acest utilizator
    if redis_client:
        # În implementarea completă, ar trebui să avem o listă de token-uri per utilizator
        # pentru a le putea revoca pe toate
        pass
    
    return jsonify({
        'message': 'Parola a fost schimbată cu succes!'
    })

# Rută pentru resetarea parolei (solicitare)
@auth_bp.route('/reset-password-request', methods=['POST'])
@sensitive_endpoint_rate_limit(limit=3, window=3600)  # Limitează la 3 încercări pe oră
def reset_password_request():
    data = request.get_json()
    
    # Validare date
    if not data or not data.get('email'):
        return jsonify({'error': 'Adresa de email este obligatorie!'}), 400
    
    # Caută utilizatorul
    user = User.query.filter_by(email=data['email']).first()
    
    if not user:
        # Nu dezvăluim dacă email-ul există sau nu (securitate)
        return jsonify({
            'message': 'Dacă adresa de email există în sistem, veți primi instrucțiuni pentru resetarea parolei.'
        })
    
    # Generează token pentru resetare parolă
    reset_token_payload = {
        'user_id': user.uuid,
        'purpose': 'password_reset',
        'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1)  # Expiră în 1 oră
    }
    
    reset_token = jwt.encode(reset_token_payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    
    # În implementarea reală, aici ar trebui să trimitem un email cu link-ul de resetare
    # Pentru acest exemplu, doar returnăm token-ul
    
    return jsonify({
        'message': 'Dacă adresa de email există în sistem, veți primi instrucțiuni pentru resetarea parolei.',
        'debug_token': reset_token  # Doar pentru dezvoltare, nu ar trebui să fie în producție
    })

# Rută pentru resetarea parolei (confirmare)
@auth_bp.route('/reset-password-confirm', methods=['POST'])
@sensitive_endpoint_rate_limit(limit=3, window=3600)  # Limitează la 3 încercări pe oră
def reset_password_confirm():
    data = request.get_json()
    
    # Validare date
    if not data or not data.get('token') or not data.get('new_password'):
        return jsonify({'error': 'Date incomplete!'}), 400
    
    try:
        # Decodifică token-ul
        token_data = jwt.decode(data['token'], JWT_SECRET, algorithms=[JWT_ALGORITHM])
        
        # Verifică scopul token-ului
        if token_data.get('purpose') != 'password_reset':
            return jsonify({'error': 'Token invalid!'}), 400
        
        # Caută utilizatorul
        user = User.query.filter_by(uuid=token_data['user_id']).first()
        
        if not user:
            return jsonify({'error': 'Utilizator negăsit!'}), 404
        
        # Schimbă parola
        user.set_password(data['new_password'])
        
        from src.main import db
        db.session.commit()
        
        # Revocă toate token-urile existente pentru acest utilizator
        if redis_client:
            # În implementarea completă, ar trebui să avem o listă de token-uri per utilizator
            # pentru a le putea revoca pe toate
            pass
        
        return jsonify({
            'message': 'Parola a fost resetată cu succes!'
        })
        
    except jwt.ExpiredSignatureError:
        return jsonify({'error': 'Token expirat!'}), 400
    except jwt.InvalidTokenError:
        return jsonify({'error': 'Token invalid!'}), 400
    except Exception as e:
        return jsonify({'error': f'Eroare la procesarea cererii: {str(e)}'}), 400
