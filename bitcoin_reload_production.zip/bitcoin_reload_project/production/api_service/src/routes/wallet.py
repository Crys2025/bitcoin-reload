from flask import Blueprint, jsonify, request, abort
from src.main import db, blockchain_rpc_call
from src.models.wallet import Wallet
from src.models.transaction import Transaction
from src.models.user import User
from src.routes.user import token_required
from datetime import datetime
import uuid
import os
from cryptography.fernet import Fernet

wallet_bp = Blueprint('wallet', __name__)

# Cheie pentru criptarea cheilor private
ENCRYPTION_KEY = os.getenv('ENCRYPTION_KEY', Fernet.generate_key().decode())
cipher_suite = Fernet(ENCRYPTION_KEY.encode())

# Rută pentru crearea unui portofel nou
@wallet_bp.route('/', methods=['POST'])
@token_required
def create_wallet(current_user):
    data = request.get_json()
    
    # Validare date
    if not data or not data.get('name'):
        return jsonify({'error': 'Numele portofelului este obligatoriu!'}), 400
    
    # Generează o nouă pereche de chei folosind RPC către nodul blockchain
    keys_response = blockchain_rpc_call("generateWalletKeys")
    
    if 'error' in keys_response:
        return jsonify({'error': 'Eroare la generarea cheilor portofelului!'}), 500
    
    keys = keys_response.get('result', {})
    
    if not keys or 'address' not in keys or 'publicKey' not in keys or 'privateKey' not in keys:
        return jsonify({'error': 'Date incomplete pentru portofel!'}), 500
    
    # Criptează cheia privată
    encrypted_private_key = cipher_suite.encrypt(keys['privateKey'].encode()).decode()
    
    # Creează portofelul
    wallet = Wallet(
        user_id=current_user.id,
        name=data['name'],
        address=keys['address'],
        public_key=keys['publicKey'],
        encrypted_private_key=encrypted_private_key
    )
    
    db.session.add(wallet)
    db.session.commit()
    
    return jsonify({
        'message': 'Portofel creat cu succes!',
        'wallet': wallet.to_dict()
    }), 201

# Rută pentru listarea portofelelor utilizatorului
@wallet_bp.route('/', methods=['GET'])
@token_required
def get_wallets(current_user):
    wallets = Wallet.query.filter_by(user_id=current_user.id).all()
    
    # Actualizează soldurile portofelelor
    for wallet in wallets:
        balance_response = blockchain_rpc_call("getBalance", [wallet.address])
        if 'result' in balance_response:
            wallet.balance = balance_response['result']
            db.session.commit()
    
    return jsonify({
        'wallets': [wallet.to_dict() for wallet in wallets]
    })

# Rută pentru obținerea unui portofel specific
@wallet_bp.route('/<wallet_id>', methods=['GET'])
@token_required
def get_wallet(current_user, wallet_id):
    wallet = Wallet.query.filter_by(uuid=wallet_id, user_id=current_user.id).first()
    
    if not wallet:
        return jsonify({'error': 'Portofel negăsit!'}), 404
    
    # Actualizează soldul portofelului
    balance_response = blockchain_rpc_call("getBalance", [wallet.address])
    if 'result' in balance_response:
        wallet.balance = balance_response['result']
        db.session.commit()
    
    return jsonify({
        'wallet': wallet.to_dict()
    })

# Rută pentru actualizarea unui portofel
@wallet_bp.route('/<wallet_id>', methods=['PUT'])
@token_required
def update_wallet(current_user, wallet_id):
    wallet = Wallet.query.filter_by(uuid=wallet_id, user_id=current_user.id).first()
    
    if not wallet:
        return jsonify({'error': 'Portofel negăsit!'}), 404
    
    data = request.get_json()
    
    # Doar numele poate fi actualizat
    if 'name' in data:
        wallet.name = data['name']
        db.session.commit()
    
    return jsonify({
        'message': 'Portofel actualizat cu succes!',
        'wallet': wallet.to_dict()
    })

# Rută pentru ștergerea unui portofel
@wallet_bp.route('/<wallet_id>', methods=['DELETE'])
@token_required
def delete_wallet(current_user, wallet_id):
    wallet = Wallet.query.filter_by(uuid=wallet_id, user_id=current_user.id).first()
    
    if not wallet:
        return jsonify({'error': 'Portofel negăsit!'}), 404
    
    # Verifică dacă portofelul are tranzacții
    transactions = Transaction.query.filter(
        (Transaction.sender_wallet_id == wallet.id) | 
        (Transaction.recipient_wallet_id == wallet.id)
    ).count()
    
    if transactions > 0:
        # Nu ștergem portofelul, doar îl dezactivăm
        wallet.is_active = False
        db.session.commit()
        
        return jsonify({
            'message': 'Portofel dezactivat cu succes!'
        })
    else:
        # Ștergem portofelul complet
        db.session.delete(wallet)
        db.session.commit()
        
        return jsonify({
            'message': 'Portofel șters cu succes!'
        })

# Rută pentru trimiterea unei tranzacții
@wallet_bp.route('/<wallet_id>/send', methods=['POST'])
@token_required
def send_transaction(current_user, wallet_id):
    wallet = Wallet.query.filter_by(uuid=wallet_id, user_id=current_user.id).first()
    
    if not wallet:
        return jsonify({'error': 'Portofel negăsit!'}), 404
    
    if not wallet.is_active:
        return jsonify({'error': 'Portofel inactiv!'}), 400
    
    data = request.get_json()
    
    # Validare date
    required_fields = ['recipient_address', 'amount', 'fee']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'Câmpul {field} este obligatoriu!'}), 400
    
    # Verifică soldul
    balance_response = blockchain_rpc_call("getBalance", [wallet.address])
    if 'error' in balance_response:
        return jsonify({'error': 'Eroare la verificarea soldului!'}), 500
    
    balance = balance_response.get('result', 0)
    amount = int(data['amount'])
    fee = int(data['fee'])
    
    if balance < amount + fee:
        return jsonify({'error': 'Sold insuficient!'}), 400
    
    # Decriptează cheia privată
    private_key = cipher_suite.decrypt(wallet.encrypted_private_key.encode()).decode()
    
    # Trimite tranzacția către nodul blockchain
    tx_response = blockchain_rpc_call("sendTransaction", [{
        'sender_address': wallet.address,
        'sender_private_key': private_key,
        'recipient_address': data['recipient_address'],
        'amount': amount,
        'fee': fee
    }])
    
    if 'error' in tx_response:
        return jsonify({'error': f'Eroare la trimiterea tranzacției: {tx_response["error"]}'}), 500
    
    tx_hash = tx_response.get('result')
    
    # Găsește portofelul destinatar în baza de date (dacă există)
    recipient_wallet = Wallet.query.filter_by(address=data['recipient_address']).first()
    recipient_wallet_id = recipient_wallet.id if recipient_wallet else None
    
    # Creează înregistrarea tranzacției
    transaction = Transaction(
        tx_hash=tx_hash,
        sender_wallet_id=wallet.id,
        recipient_wallet_id=recipient_wallet_id if recipient_wallet_id else wallet.id,  # Fallback la același portofel dacă destinatarul nu este în sistem
        amount=amount,
        fee=fee
    )
    
    db.session.add(transaction)
    db.session.commit()
    
    return jsonify({
        'message': 'Tranzacție trimisă cu succes!',
        'transaction': transaction.to_dict()
    })

# Rută pentru obținerea tranzacțiilor unui portofel
@wallet_bp.route('/<wallet_id>/transactions', methods=['GET'])
@token_required
def get_wallet_transactions(current_user, wallet_id):
    wallet = Wallet.query.filter_by(uuid=wallet_id, user_id=current_user.id).first()
    
    if not wallet:
        return jsonify({'error': 'Portofel negăsit!'}), 404
    
    # Obține tranzacțiile trimise și primite
    transactions = Transaction.query.filter(
        (Transaction.sender_wallet_id == wallet.id) | 
        (Transaction.recipient_wallet_id == wallet.id)
    ).order_by(Transaction.created_at.desc()).all()
    
    return jsonify({
        'transactions': [tx.to_dict() for tx in transactions]
    })
