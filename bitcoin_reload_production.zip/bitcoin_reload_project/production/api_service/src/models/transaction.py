from src.main import db
from datetime import datetime
import uuid

class Transaction(db.Model):
    __tablename__ = 'transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(36), unique=True, nullable=False, default=lambda: str(uuid.uuid4()))
    tx_hash = db.Column(db.String(64), unique=True, nullable=False)
    sender_wallet_id = db.Column(db.Integer, db.ForeignKey('wallets.id'), nullable=False)
    recipient_wallet_id = db.Column(db.Integer, db.ForeignKey('wallets.id'), nullable=False)
    amount = db.Column(db.BigInteger, nullable=False)  # în satoshi
    fee = db.Column(db.BigInteger, nullable=False)  # în satoshi
    status = db.Column(db.String(20), nullable=False, default='pending')  # pending, confirmed, failed
    block_height = db.Column(db.Integer)
    block_hash = db.Column(db.String(64))
    confirmation_time = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __init__(self, tx_hash, sender_wallet_id, recipient_wallet_id, amount, fee):
        self.tx_hash = tx_hash
        self.sender_wallet_id = sender_wallet_id
        self.recipient_wallet_id = recipient_wallet_id
        self.amount = amount
        self.fee = fee
    
    def to_dict(self):
        return {
            'id': self.uuid,
            'tx_hash': self.tx_hash,
            'sender_wallet_id': self.sender.uuid if self.sender else None,
            'recipient_wallet_id': self.recipient.uuid if self.recipient else None,
            'amount': self.amount,
            'fee': self.fee,
            'status': self.status,
            'block_height': self.block_height,
            'block_hash': self.block_hash,
            'confirmation_time': self.confirmation_time.isoformat() if self.confirmation_time else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def __repr__(self):
        return f'<Transaction {self.tx_hash}>'
