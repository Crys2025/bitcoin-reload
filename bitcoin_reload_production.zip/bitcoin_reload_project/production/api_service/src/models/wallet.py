from src.main import db
from datetime import datetime
import uuid

class Wallet(db.Model):
    __tablename__ = 'wallets'
    
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(36), unique=True, nullable=False, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    name = db.Column(db.String(64), nullable=False)
    address = db.Column(db.String(64), unique=True, nullable=False)
    public_key = db.Column(db.String(128), nullable=False)
    encrypted_private_key = db.Column(db.Text, nullable=False)
    balance = db.Column(db.BigInteger, default=0)  # în satoshi
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relații
    transactions_sent = db.relationship('Transaction', foreign_keys='Transaction.sender_wallet_id', backref='sender', lazy=True)
    transactions_received = db.relationship('Transaction', foreign_keys='Transaction.recipient_wallet_id', backref='recipient', lazy=True)
    
    def __init__(self, user_id, name, address, public_key, encrypted_private_key):
        self.user_id = user_id
        self.name = name
        self.address = address
        self.public_key = public_key
        self.encrypted_private_key = encrypted_private_key
    
    def to_dict(self):
        return {
            'id': self.uuid,
            'name': self.name,
            'address': self.address,
            'balance': self.balance,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def __repr__(self):
        return f'<Wallet {self.name} - {self.address}>'
