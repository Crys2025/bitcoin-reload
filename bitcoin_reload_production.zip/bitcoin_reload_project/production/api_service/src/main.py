import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))  # DON'T CHANGE THIS !!!

from flask import Flask, jsonify, request, abort
from flask_sqlalchemy import SQLAlchemy
import json
import requests
import logging
from datetime import datetime

# Configurare logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('api_service.log')
    ]
)
logger = logging.getLogger(__name__)

# Inițializare aplicație Flask
app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False

# Configurare bază de date
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('DB_USERNAME', 'root')}:{os.getenv('DB_PASSWORD', 'password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '3306')}/{os.getenv('DB_NAME', 'mydb')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Configurare conexiune la nodul blockchain
BLOCKCHAIN_RPC_URL = os.getenv('BLOCKCHAIN_RPC_URL', 'http://localhost:8545')
BLOCKCHAIN_RPC_USER = os.getenv('BLOCKCHAIN_RPC_USER', '')
BLOCKCHAIN_RPC_PASSWORD = os.getenv('BLOCKCHAIN_RPC_PASSWORD', '')

# Importare modele și rute
from src.models.user import User
from src.models.wallet import Wallet
from src.models.transaction import Transaction
from src.routes.user import user_bp
from src.routes.blockchain import blockchain_bp
from src.routes.wallet import wallet_bp
from src.routes.admin import admin_bp

# Înregistrare blueprints
app.register_blueprint(user_bp, url_prefix='/api/users')
app.register_blueprint(blockchain_bp, url_prefix='/api/blockchain')
app.register_blueprint(wallet_bp, url_prefix='/api/wallets')
app.register_blueprint(admin_bp, url_prefix='/api/admin')

# Funcție pentru apeluri RPC către nodul blockchain
def blockchain_rpc_call(method, params=None):
    headers = {'content-type': 'application/json'}
    payload = {
        "jsonrpc": "2.0",
        "id": "bitcoin-reload-api",
        "method": method,
        "params": params or []
    }
    
    auth = None
    if BLOCKCHAIN_RPC_USER and BLOCKCHAIN_RPC_PASSWORD:
        auth = (BLOCKCHAIN_RPC_USER, BLOCKCHAIN_RPC_PASSWORD)
    
    try:
        response = requests.post(
            BLOCKCHAIN_RPC_URL, 
            data=json.dumps(payload), 
            headers=headers,
            auth=auth
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        logger.error(f"RPC call failed: {e}")
        return {"error": str(e)}

# Rută de bază pentru verificarea stării API
@app.route('/')
def index():
    return jsonify({
        "name": "Bitcoin Reload API Service",
        "version": "1.0.0",
        "status": "online",
        "timestamp": datetime.now().isoformat()
    })

# Rută pentru verificarea stării nodului blockchain
@app.route('/api/status')
def status():
    # Verifică starea nodului blockchain
    blockchain_status = blockchain_rpc_call("getBlockchainInfo")
    
    # Verifică starea bazei de date
    db_status = "online"
    try:
        db.session.execute("SELECT 1")
    except Exception as e:
        db_status = f"offline: {str(e)}"
    
    return jsonify({
        "api_service": {
            "status": "online",
            "version": "1.0.0",
            "timestamp": datetime.now().isoformat()
        },
        "blockchain_node": {
            "status": "online" if "result" in blockchain_status else "offline",
            "info": blockchain_status.get("result", {"error": blockchain_status.get("error", "Unknown error")})
        },
        "database": {
            "status": db_status
        }
    })

# Middleware pentru logging
@app.before_request
def log_request_info():
    logger.info(f"Request: {request.method} {request.path} - IP: {request.remote_addr}")

# Middleware pentru tratarea erorilor
@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Resource not found"}), 404

@app.errorhandler(500)
def server_error(error):
    logger.error(f"Server error: {error}")
    return jsonify({"error": "Internal server error"}), 500

# Rulare aplicație
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
